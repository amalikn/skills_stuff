"""Deterministic commercial calculators."""
