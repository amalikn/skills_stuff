# Repository guidance

## Scope

Protect the distinction between evidence, assumptions, calculations, recommendations, and approvals. Do not add a claimed regulatory, tax, customs, product-compliance, or market fact without a source record and an evidence label.

## Implementation rules

- Use `Decimal` for monetary and percentage calculations; do not use binary floats for financial outputs.
- Put deterministic rules in `src/bftoolkit/calculators/` and test exact rounding behaviour.
- Keep LLM integrations behind `src/bftoolkit/llm/contracts.py`; no provider SDK may be a core dependency.
- Domain packs ask structured questions and name evidence required. They never decide eligibility or insert jurisdictional rules from memory.
- A human approval is required for an `APPROVED` decision. Never make an external write, purchase, filing, listing, or communication from a skill by default.

## Validation

Run `uv run pytest` and `python tools/validate_repository.py`. Do not claim a regulatory pack is current merely because its checklist passes.
