# skill-ai-it

## Contents

- [Purpose](#purpose)
- [Modes](#modes)
- [Package layout](#package-layout)
- [Key rules](#key-rules)
- [Tool stack](#tool-stack)
- [Usage intent](#usage-intent)

Reusable AI governance and navigation bootstrap skill for project folders.

## Purpose

`skill-ai-it` analyzes a target folder and creates or refreshes governance, context-routing, and AI navigation files.

It supports mixed projects where content may include code, scripts, Markdown design notes, architecture docs, roadmap files, scratchpads, changelogs, and conceptual planning documents.

## Modes

| Mode | Purpose |
|---|---|
| `bootstrap` | Create initial governance scaffold for a new/light project |
| `navigation-add` | Add AI navigation starter files to an existing project |
| `refresh` | Safely update managed sections without overwriting custom content |
| `audit` | Report missing/stale/conflicting governance/context files |
| `promote` | Authorize promotion of candidates from `ARCHCORE_PROMOTION_CANDIDATES.md` or explicitly request durable promotion into `.archcore/` |

## Package layout

```text
skill-ai-it/
├── SKILL.md
├── README.md
├── AGENTS.md
├── CLAUDE.md
├── AI_NAVIGATION.md
├── context-map.yaml
├── CHANGELOG.md
├── ARCHITECTURE.md
├── SCRATCHPAD.md
├── templates/
│   ├── AI_NAVIGATION.md
│   ├── context-map.yaml
│   ├── repomix.config.json
│   ├── AGENTS-navigation-block.md
│   ├── justfile
│   ├── scripts-README.md
│   └── context-preflight.sh
└── patterns/
    ├── archcore-routing.md
    ├── memory-bank-structure.md
    ├── drift-audit.md
    └── script-task-audit-checklist.md
```

## Key rules

- `SKILL.md` owns orchestration logic.
- `ARCHITECTURE.md` explains the skill package architecture and tool stack.
- `templates/` owns reusable generated-file templates.
- `patterns/` owns optional guidance modules.
- `CHANGELOG.md` owns durable package history and governance/navigation change history.
- Generic preflight behavior is maintained in this skill package; repo-local preflight scripts are explicit opt-in artifacts only.
- When the `archcore` CLI is available, `skill-ai-it` initializes `.archcore/` during bootstrap, navigation-add, or refresh runs.
- When a `justfile` exists, `just --list` and `just <task>` are the preferred task discovery and execution commands.
- `scripts/README.md`, when present, is the human/agent-readable script inventory.
- Agents must not assume arbitrary scripts are safe to run unless cataloged or inspected.
- Repeat runs must be safe and must not overwrite user-authored content wholesale.
- Existing files should be updated through managed blocks or `.proposed` files.
- `.archcore/`, if present in a target project, is treated as durable structured truth.
- `graphify-out/` and `.ai-context/` are generated support artifacts, not canonical truth.

## Tool stack

`skill-ai-it` coordinates four project-context tools. Graphify and Repomix are actively invoked when their CLIs are available; Archcore is initialized when its CLI is available; a task-runner layer is established using the lightest appropriate tool for the project.

- Archcore
  - General value: gives a project a structured place for durable engineering truth, so decisions, rules, specs, guides, and plans are not scattered across chat logs, scratchpads, and stale docs.
  - Best for: accepted decisions, project rules, design contracts, operating guides, and approved implementation plans that should survive context resets and agent handoffs.
  - In `skill-ai-it`: initialized under `.archcore/` during bootstrap, navigation-add, or refresh. After init, emits `ARCHCORE_PROMOTION_CANDIDATES.md` with durable content candidates extracted from governance markdown. Content is written into `.archcore/` only via `promote` mode.
  - Source-of-truth status: canonical when initialized. `archcore init` is allowed setup; content changes inside `.archcore/` still require explicit authorization.

- Graphify
  - General value: turns a repository or document set into a relationship graph, making it easier to see how files, concepts, modules, and docs connect.
  - Best for: discovery, impact analysis, navigation, and helping agents avoid missing related files in mixed code/docs projects.
  - In `skill-ai-it`: actively runs `graphify update .` on every bootstrap, navigation-add, and refresh run. Initializes `graphify-out/` if missing; refreshes the graph if present. Required for full skill operation.
  - Source-of-truth status: generated support only. Useful for navigation and discovery, but not authoritative by itself.

- Repomix
  - General value: packages selected repository files into a deterministic AI-readable context bundle, so agents can load the same curated project context repeatedly.
  - Best for: context compaction recovery, handoff, review, and giving an AI model a stable snapshot of the important files without manually pasting them.
  - In `skill-ai-it`: actively runs `repomix --config repomix.config.json` on every bootstrap, navigation-add, and refresh run. Creates `repomix.config.json` from template if missing, then runs.
  - Source-of-truth status: generated support; `repomix.config.json` is governed, but `.ai-context/` output is rebuildable.

- just / task runners
  - General value: defines project-local runnable tasks with names, descriptions, and executable entrypoints so agents can discover and run them safely.
  - Best for: replacing ambiguous raw script execution with cataloged commands such as `just --list` and `just <task>`.
  - In `skill-ai-it`: `justfile` is the preferred lightweight task catalog for new projects. Existing projects keep their canonical runner (Taskfile.yml, Makefile, package.json scripts). `scripts/README.md` explains tasks for humans and agents.
  - Source-of-truth status: the existing canonical runner is authoritative when present. Raw scripts remain unknown safety until cataloged or inspected.

The intended authority order is:

```text
.archcore/ + governed markdown + source files
        -> justfile / existing task runner + scripts/README.md
        -> AI_NAVIGATION.md + context-map.yaml
        -> Graphify / Repomix generated outputs
        -> agent context loading
```

Graphify and Repomix should not promote generated conclusions back into project truth automatically. If generated output reveals a useful fact, promote it through the normal governance path: update source docs, `.archcore/`, `AI_NAVIGATION.md`, `context-map.yaml`, or `CHANGELOG.md` as appropriate.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the detailed architecture and tool-stack policy.

## Usage intent

Use this skill when asked to:

- bootstrap a project
- add AI navigation
- refresh governance
- audit context drift
- make agent context less fragile after compaction
- create repeat-safe context-routing files
- append durable governance/navigation changes to `CHANGELOG.md`
