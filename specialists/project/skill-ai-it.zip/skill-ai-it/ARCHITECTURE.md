# skill-ai-it Architecture

## Contents

- [Package roles](#package-roles)
- [Flow](#flow)
- [Tool stack](#tool-stack)
  - [Archcore](#archcore)
  - [Graphify](#graphify)
  - [Repomix](#repomix)
- [Script and Task Inventory Layer](#script-and-task-inventory-layer)
- [Runtime model](#runtime-model)
- [Repeat-safety model](#repeat-safety-model)

`skill-ai-it` is a reusable governance/navigation skill. It analyzes a target folder, infers what project context exists, and creates or refreshes repeat-safe guidance files without making the target project depend on this skill package at runtime.

## Package roles

| Area | Role |
|---|---|
| `SKILL.md` | Orchestration contract: modes, phases, repeat-safety rules, and embedded fallbacks. |
| `templates/` | Reusable generated-file templates for target projects. |
| `patterns/` | Optional guidance modules for concepts that may apply to a target project. |
| `README.md` | Human overview of the skill package. |
| `AI_NAVIGATION.md` | Maintenance router for agents editing this skill package. |
| `context-map.yaml` | Machine-readable routing map for this skill package. |
| `CHANGELOG.md` | Durable package history and governance/navigation change ledger. |

## Flow

```text
Operator request
      |
      v
skill-ai-it / SKILL.md
      |
      +--> Inventory target folder
      |        |
      |        +--> README / AGENTS / CHANGELOG / existing docs
      |        +--> code, configs, scripts, generated context
      |
      +--> Infer mode
      |        |
      |        +--> bootstrap
      |        +--> navigation-add
      |        +--> refresh
      |        +--> audit
      |        +--> promote
      |
      +--> Apply governed outputs
               |
               +--> Governance files
               |      README.md
               |      AGENTS.md
               |      CLAUDE.md
               |      SCRATCHPAD.md
               |      CHANGELOG.md
               |      AI_NAVIGATION.md
               |      context-map.yaml
               |
               +--> Durable truth layer
               |      .archcore/
               |        archcore init → .archcore/ container (bootstrap/refresh)
               |        candidates report → ARCHCORE_PROMOTION_CANDIDATES.md
               |        promote → .archcore/ content files (explicit only)
               |
               +--> Script/task inventory layer
               |      justfile (preferred lightweight catalog)
               |      existing runner (Taskfile.yml / Makefile / package.json)
               |      scripts/README.md
               |      just --list / just <task>  (when justfile present)
               |
               +--> Active context generation (CLIs invoked when available)
                      graphify update .      → graphify-out/
                      repomix --config ...   → .ai-context/
```

```text
Source-of-truth direction

.archcore/ + governed markdown + source files
              |
              v
justfile / existing task runner + scripts/README.md
              |
              v
AI_NAVIGATION.md + context-map.yaml
              |
              v
Graphify and Repomix generated outputs
              |
              v
Agent navigation and context loading

Generated outputs do not flow back into source-of-truth unless reviewed and promoted.
```

## Tool stack

### Archcore

Archcore provides structured durable project truth under `.archcore/`.

`skill-ai-it` uses Archcore when the `archcore` CLI is available. During `bootstrap`, `navigation-add`, or `refresh`, the skill initializes `.archcore/` with `archcore init` when it is missing. After initialization, target-project routing should treat `.archcore/` as active structured truth for durable decisions, rules, specs, guides, and plans.

`archcore init` is setup. Creating or changing Archcore content files remains governed: propose ADRs, rules, specs, guides, or plans unless the user explicitly authorizes those content changes.

During `bootstrap` and `refresh`, after `archcore init`, `skill-ai-it` scans existing governance files and writes `ARCHCORE_PROMOTION_CANDIDATES.md` — a structured report of durable content candidates (decisions, rules, specs, guides, plans) with source references and confidence ratings. This bridges the gap between `archcore init` (setup) and `promote` (content creation). No `.archcore/` content files are created until `promote` mode is explicitly invoked.

### Graphify

Graphify produces generated relationship/navigation artifacts under `graphify-out/`, such as `GRAPH_REPORT.md` and `graph.json`.

`skill-ai-it` actively invokes `graphify update .` on every `bootstrap`, `navigation-add`, and `refresh` run when the CLI is available. If `graphify-out/` is missing, `graphify update .` initializes it; if already present, it refreshes the graph. Graphify is a required tool for full skill operation — when unavailable, the Graphify step is skipped and reported.

Graphify output remains generated support, not canonical truth. Answers and durable decisions should be grounded in source files, `.archcore/`, or governance docs.

### Repomix

Repomix builds deterministic AI-readable context packs, usually under `.ai-context/`, from `repomix.config.json`.

`skill-ai-it` actively runs `repomix --config repomix.config.json` on every `bootstrap`, `navigation-add`, and `refresh` run when the CLI is available. If `repomix.config.json` is missing, the skill creates it from `templates/repomix.config.json` first, then runs Repomix. Repomix output is generated support, not source-of-truth content. The config file is governed; the generated `.ai-context/` output is rebuildable.

## Script and Task Inventory Layer

Project-local automation needs a separate inventory layer because raw scripts do not explain their purpose, side effects, or safety.

- `justfile` is the preferred lightweight task catalog for new projects. Agents use `just --list` to discover tasks and `just <task>` to run them.
- Existing task runners take priority: if the project already has a `Taskfile.yml`, `Makefile`, or `package.json` scripts, that remains the canonical runner.
- `scripts/README.md` is the human/agent-readable operational catalog. Created during bootstrap and refresh when scripts or tasks exist.
- Graphify is relationship discovery only; it can help find related scripts and files, but it does not certify script safety.
- Repomix is context packing only; it can include scripts and catalogs in an AI context bundle, but it does not decide what is safe to run.
- Archcore is for durable operational procedure promotion only; stable, accepted procedures may be promoted into `.archcore/guides/`, but not every script becomes Archcore truth automatically.
- Raw scripts under `scripts/` are not automatically safe.
- Agent preference order: existing canonical runner → `just --list` / `just <task>` → `scripts/README.md` → other runners → raw scripts after inspection.
- If only raw scripts exist, the skill should generate or propose `scripts/README.md` inventory entries before agents rely on them.

## Runtime model

The skill package is the maintained source for generic behavior. Target projects should not need local copies of the skill logic.

Repo-local scripts such as `scripts/context-preflight.sh` are explicit opt-in artifacts only. They can be useful as compatibility wrappers, but they must not become a second source of truth for generic Archcore, Graphify, or Repomix behavior.

## Repeat-safety model

The skill favors reversible, scoped changes:

- update managed blocks instead of overwriting files wholesale
- append `CHANGELOG.md` instead of rewriting history
- write `.proposed` files for risky YAML/JSON changes
- report created, updated, skipped, and proposed files separately
- keep generated support artifacts separate from canonical truth
