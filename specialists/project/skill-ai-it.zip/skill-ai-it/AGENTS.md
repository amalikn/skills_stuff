Title: skill-ai-it Agent Policy
Category: agent-governance-guide
Status: current
Authority: local-supplement
Scope: skill-ai-it package maintenance
Last reviewed: 2026-05-22
Summary: Rules for maintaining the skill-ai-it package.

# AGENTS.md

## Working rules

- Treat `SKILL.md` as the orchestration contract.
- Treat `templates/` as the source for reusable generated-file content.
- Treat `patterns/` as reusable optional guidance modules.
- Treat `CHANGELOG.md` as the durable package history and governance/navigation change ledger.
- Do not let embedded fallback examples in `SKILL.md` drift away from external templates.
- If a template changes, check whether the matching fallback/example in `SKILL.md` should also change.
- If `SKILL.md` changes the expected package layout, update `README.md`, `AI_NAVIGATION.md`, and `context-map.yaml`.
- If `SKILL.md`, templates, patterns, or governance routing changes materially, append a concise entry to `CHANGELOG.md`.
- Preserve repeat-safe behaviour:
  - no wholesale overwrites
  - use managed blocks
  - write `.proposed` files for risky YAML/JSON changes
  - report created/updated/skipped/proposed files separately
- Keep `CLAUDE.md` as a thin wrapper around this file.
- Keep this package tool-agnostic: it should work for Codex, Claude Code, and local LLM workflows.
- Before running project-local scripts or automation, inspect the task catalog in this order:
  - `justfile` / `Justfile`
  - `scripts/README.md`
  - `Taskfile.yml`
  - `Makefile`
  - `package.json`
- Prefer `just --list` and `just <task>` when a `justfile` is present.
- Prefer cataloged tasks over raw scripts.
- Treat uncataloged scripts as unknown safety.
- Do not run destructive, review-required, or unknown-safety tasks without review.
- When adding, modifying, or removing scripts or tasks, update or propose an update to `scripts/README.md`.

<!-- BEGIN skill-ai-it:navigation -->

## AI navigation and context preflight

Before editing this skill package:

1. Read `AI_NAVIGATION.md`.
2. Read `context-map.yaml`.
3. Read `SKILL.md`.
4. Read recent entries in `CHANGELOG.md`.
5. Read relevant files under `templates/` and `patterns/`.
6. If changing a generated-file template, check whether `SKILL.md` still has matching fallback/reference content.
7. If sources conflict, stop and report the conflict before editing.

<!-- END skill-ai-it:navigation -->

## Maintenance boundaries

- Do not add runtime/cache/generated outputs to the skill package.
- Do not store project-specific target outputs here.
- Do not add secrets or machine-local credentials.
- Keep examples generic and reusable.
