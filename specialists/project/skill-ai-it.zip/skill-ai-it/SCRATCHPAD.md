# SCRATCHPAD

Agent working memory for `skill-ai-it`.

Use for current state, open items, anchors, and short session summaries. Full session detail belongs in memory-keeper; structured project state belongs in mcp-project-context.

---

<!-- KEEP: updated 2026-05-22 post-slurp (mise-removal session + coherence cleanup) -->

## Current state

**Phase:** Package stable — mise fully removed; just is the only task runner this skill knows.

`skill-ai-it` is the canonical governance/navigation bootstrap skill at `/Volumes/Data/_ai/_skills/skills_stuff/specialists/project/skill-ai-it`. Previous sessions: coherence cleanup, active tool orchestration. This session: (1) just-preferred refactor; (2) full mise excision — `templates/mise.toml` deleted, all mise references removed from all 15 package files. `justfile` + `scripts/README.md` are now the sole task catalog layer.

---

## Open items

- [ ] Apply `/skill-ai-it refresh` to `/Volumes/Data/_ai/_tool/tools_stuff/openbb` and verify `.archcore/` initialization and Graphify/Repomix active invocation.
- [ ] Apply `/skill-ai-it refresh` to `/Volumes/Data/_ai/_skills/skills_stuff/invoice-finance-analyst`.
- [x] ~~Decide whether to add a governed script inventory / `mise` task policy to `skill-ai-it`.~~ Done 2026-05-22: implemented.
- [x] ~~Decide whether `.DS_Store` and `codex_prompt_fix_skill_ai_it_changelog_governance.md` should remain.~~ Done 2026-05-22: archived/removed.

---

## Key anchors

| Item | Detail |
|---|---|
| Canonical package | `/Volumes/Data/_ai/_skills/skills_stuff/specialists/project/skill-ai-it` |
| Channel | `skill-ai-it` |
| Project-context project | `skills_stuff` / `b8c5525e-3e2f-4fb5-bf87-e5751f3ad49c` |
| Archcore CLI | `/Users/malik.ahmad/.local/bin/archcore`, version `v0.3.6` |
| Graphify CLI | `/Users/malik.ahmad/.local/bin/graphify` |
| Repomix CLI | `/opt/homebrew/bin/repomix`, version `1.13.1` |

---

## Recent decisions

- 2026-05-22 — **mise removed from skill entirely.** `templates/mise.toml` deleted. Skill generates no mise files, detects no mise config, and references mise nowhere. `just` + `justfile` is the task runner. Other existing runners (Taskfile.yml, Makefile, package.json) are still detected and respected.
- 2026-05-22 — CHANGELOG heading format: `YYYYMMDD_HHMM` replaces `YYYY-MM-DD`.
- 2026-05-22 — scripts/README.md must be created during refresh (not only bootstrap) when scripts/tasks exist and file is missing (circular dependency fix).
- 2026-05-22 — Rule 12 added to navigation block: update scripts/README.md when scripts/tasks change (write-side obligation).
- 2026-05-22 — Graphify runs `graphify update .` on every active-mode run. Required for full skill operation when CLI is available.
- 2026-05-22 — Repomix runs `repomix --config repomix.config.json` on every active-mode run. Creates config from template if missing.
- 2026-05-22 — Repo-local `scripts/context-preflight.sh` is explicit opt-in only; generic behavior stays maintained in `skill-ai-it`.

---

## Session history

### 2026-05-22 — markdown guide enforcement + policy guard fixes + slurp
- Added "Markdown quality rules" section to SKILL.md Phase 4 — enforces markdown-guide.md for every .md file created/updated: naming, TOC (>100 lines), links, quality pass.
- Fixed policy_guard: corrected skills_stuff path; raised max_agents_lines 25→120 for mcp_stuff/skills_stuff/project_stuff; added qwen3.5:35b to ollama allowlist.
- Slurped to MK (2 new keys, 1 updated) + PC; checkpoints: `slurp-20260522-skill-ai-it-markdown-guide`.

### 2026-05-22 — mise-removal coherence cleanup + slurp
- Cleaned SCRATCHPAD.md session history of stale mise operational references; remaining references are accurate history or labeled "(superseded)".
- Answered justfile bootstrap policy: justfile created only when scripts/automation present AND no canonical runner exists — not for every project.
- Slurped session to memory-keeper (3 new keys, 2 updated) + project-context; checkpoints: `slurp-20260522-skill-ai-it-mise-removal`.

### 2026-05-22 — full mise excision
- `templates/mise.toml` deleted; mise removed from all 15 operational package files (detection order, file-creation table, all mode behaviors, embedded blocks, templates, patterns, ARCHITECTURE, README, AGENTS).
- CHANGELOG entry `20260522_1900` added. `~/.claude/skills/skill-ai-it/SKILL.md` synced; `~/.agents/skills/skill-ai-it/` confirmed symlink (current).
- Zero live mise references in operational files; CHANGELOG historical entries retained as accurate history.

### 2026-05-22 — just-preferred task-runner refactor

- Implemented 19-section spec from `docs/replace-mise-with-just-20260522_1652.md` (just-preferred / mise-optional pass — superseded by mise-removal session).
- Added `templates/justfile`; initial intent was to keep `templates/mise.toml` optional — later fully deleted.
- Updated 12 files; see CHANGELOG entry `20260522_1800`.

### 2026-05-22 — coherence sweep + tool-stack active invocation

- Ran full coherence audit and cleanup: SKILL.md Phase 4 split into three sections, SCRATCHPAD.md formalized, root hygiene, `.gitignore` created.
- Changed passive tool policy to active orchestration: Graphify runs on every rerun; Repomix runs on every rerun.
- Updated ARCHITECTURE.md (flow diagram, Graphify required, Repomix active), README.md (tool count, active descriptions).
- All validation checks passed: 23 required files present, TOML/YAML/bash all valid.

### 2026-05-22 — governance/tool-stack hardening (earlier session)

- Promoted `CHANGELOG.md`, added `ARCHITECTURE.md`, and documented Archcore, Graphify, Repomix roles plus text flow diagrams.
- Updated `SKILL.md` policy for Archcore initialization, optional local preflight scripts, and package navigation coherence.
- Researched script/task tooling; initially implemented `mise tasks` as optional task layer (superseded — mise fully removed in later session).
- Evidence basis: memory-keeper keys `skill-ai-it.maintenance.20260522`, `skill-ai-it.archcore.policy.20260522`, `skill-ai-it.preflight.policy.20260522`, `skill-ai-it.script-inventory.research.20260522`.

---

## Next actions

- Retry skills_stuff commit — policy guard passes; files staged (skill-ai-it/, skill-smc/, skills/, personal/, governance/plans/, README.md, SCRATCHPAD.md).
- Refresh OpenBB with updated skill and verify justfile/Graphify/Archcore active initialization works.
- Refresh invoice-finance-analyst with updated skill.

---

## Memory pointers

- memory-keeper channel: `skill-ai-it`
- memory-keeper keys: `skill-ai-it.maintenance.20260522`, `skill-ai-it.archcore.policy.20260522`, `skill-ai-it.preflight.policy.20260522`, `skill-ai-it.script-inventory.research.20260522`, `skill-ai-it.tooling.installs.20260522`, `skill-ai-it.next-actions.20260522`, `skill-ai-it.mise-removal.20260522`, `skill-ai-it.just-bootstrap-policy.20260522`, `skill-ai-it.scratchpad-cleanup.20260522`, `skill-ai-it.markdown-guide-enforcement.20260522`, `skill-ai-it.policy-guard-fixes.20260522`
- project-context project ID: `b8c5525e-3e2f-4fb5-bf87-e5751f3ad49c`
- project-context checkpoint: `slurp-20260522-skill-ai-it-markdown-guide`
