# Script / Task Inventory Audit Checklist

## 1. Discovery

- [ ] Check whether `justfile` exists.
- [ ] Check whether `scripts/README.md` exists.
- [ ] Check for raw scripts under `scripts/`.
- [ ] Check for other task runners:
  - [ ] `Taskfile.yml`
  - [ ] `Makefile`
  - [ ] `package.json`
  - [ ] `.github/workflows/`
  - [ ] `ansible/`
  - [ ] `playbooks/`
  - [ ] `scripts/*.py`
  - [ ] `scripts/*.sh`

## 2. Catalog Coverage

- [ ] Every recipe in `justfile` is listed or discoverable via `just --list`.
- [ ] Every important script under `scripts/` is listed in `scripts/README.md`.
- [ ] Catalog does not reference deleted scripts.
- [ ] Catalog does not reference deleted tasks.
- [ ] Duplicate task/script entries are removed or explained.

## 3. Safety Classification

- [ ] Each task/script has a safety label.
- [ ] `unknown` tasks are not treated as safe.
- [ ] Destructive tasks are clearly marked.
- [ ] Tasks that modify files are marked `modifies-files`.
- [ ] Tasks that call external services are marked `external-network`.
- [ ] Tasks requiring credentials are marked `requires-credentials`.
- [ ] Tasks requiring secrets are marked `requires-secrets`.
- [ ] Long-running tasks are marked `long-running`.

## 4. Inputs and Outputs

- [ ] Inputs are documented.
- [ ] Outputs are documented.
- [ ] Generated artifact paths are documented.
- [ ] Persistent state paths are documented.
- [ ] Runtime/cache paths are not confused with source files.
- [ ] Secret values are not documented.

## 5. Idempotency

- [ ] Repeat-safe tasks are marked idempotent.
- [ ] Non-idempotent tasks explain why.
- [ ] Cleanup/reset tasks are clearly separated from normal tasks.
- [ ] Deployment/migration/destructive tasks require review.

## 6. Agent Routing

- [ ] `AI_NAVIGATION.md` tells agents to inspect task catalog first.
- [ ] `context-map.yaml` routes script/task/automation questions correctly.
- [ ] `repomix.config.json` includes task catalog files.
- [ ] Generated outputs like `.ai-context/` and `graphify-out/` are not treated as source truth.
- [ ] Archcore is used only for durable operational procedures, not every script.

## 7. Validation Commands

Run from repo root:

```bash
just --list 2>/dev/null || true
test -f scripts/README.md && sed -n '1,220p' scripts/README.md || true
find scripts -maxdepth 2 -type f 2>/dev/null | sort || true
python - <<'PY'
import json, pathlib, sys
p = pathlib.Path("repomix.config.json")
if p.exists():
    json.loads(p.read_text())
    print("repomix config: OK")
else:
    print("repomix config: missing/skipped")
PY
python - <<'PY'
import pathlib
needles = [
    "justfile",
    "scripts/README.md",
    "Script and Task Navigation",
    "Script Inventory",
    "unknown",
    "destructive",
]
for n in needles:
    hits = []
    for p in pathlib.Path(".").rglob("*"):
        if p.is_file() and ".git" not in p.parts:
            try:
                if n in p.read_text(errors="ignore"):
                    hits.append(str(p))
            except Exception:
                pass
    print(f"{n}: {len(hits)} hit(s)")
PY
```

## 8. Audit Verdict

| Area | Status | Notes |
|---|---|---|
| Runnable task catalog exists | PASS / PARTIAL / FAIL |  |
| Human-readable script inventory exists | PASS / PARTIAL / FAIL |  |
| Safety labels present | PASS / PARTIAL / FAIL |  |
| Drift detected | YES / NO |  |
| Agent routing updated | PASS / PARTIAL / FAIL |  |
| Ready for agent use | YES / NO |  |
