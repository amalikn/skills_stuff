# Drift Audit Pattern

Use this pattern when auditing whether AI agents can find the right project context.

## Checkpoints

1. Confirm `AGENTS.md` points to `AI_NAVIGATION.md`.
2. Confirm `AI_NAVIGATION.md` points to `context-map.yaml`.
3. Confirm `CHANGELOG.md` exists and recent governance/navigation changes are recorded.
4. Confirm `context-map.yaml` has routing for architecture, planning, governance, implementation, and documentation.
5. Confirm `.archcore/` is either present and routed, or absent and treated as optional.
6. Confirm `memory-bank/` is either present and routed, or absent and treated as optional.
7. Confirm generated context paths are excluded from source-of-truth decisions.
8. Confirm `SCRATCHPAD.md` is marked transient.
9. Confirm repeat-run managed blocks exist where needed.
10. Confirm risky YAML/JSON changes use `.proposed` files.
11. Confirm drift/conflict policy says stop-and-report.

## Output

Report:

- missing files
- stale sections
- duplicate/conflicting authority
- unsafe overwrite risks
- recommended smallest fix
