# Changelog — skill-ai-it

## Contents

- [20260523_1045 — fix: Archcore candidate report completion gate](#20260523_1045--fix-archcore-candidate-report-completion-gate)
- [20260523_0000 — feat: Archcore promotion candidate reporting](#20260523_0000--feat-archcore-promotion-candidate-reporting)
- [20260522_1755 — fix: embedded justfile fallback + deploy templates/ and patterns/ to installed copy](#20260522_1755--fix-embedded-justfile-fallback-deploy-templates-and-patterns-to-installed-copy)
- [20260522_1807 — feat: markdown quality rules enforced during file creation/update](#20260522_1807--feat-markdown-quality-rules-enforced-during-file-creationupdate)
- [20260522_1900 — remove: mise removed from skill entirely](#20260522_1900--remove-mise-removed-from-skill-entirely)
- [20260522_1800 — refactor: just-preferred task-runner strategy replaces mise-first](#20260522_1800--refactor-just-preferred-task-runner-strategy-replaces-mise-first)
- [20260522_1700 — fix: scripts/README.md update obligation added to navigation block](#20260522_1700--fix-scriptsreadmemd-update-obligation-added-to-navigation-block)
- [20260522_1643 — fix: scripts/README.md creation in refresh mode](#20260522_1643--fix-scriptsreadmemd-creation-in-refresh-mode)
- [20260522_1434 — full coherence sweep](#20260522_1434--full-coherence-sweep)
- [20260522_1432 — ARCHITECTURE.md tool-stack update for active CLI roles](#20260522_1432--architecturemd-tool-stack-update-for-active-cli-roles)
- [20260522_1431 — tool-stack auto-invocation policy](#20260522_1431--tool-stack-auto-invocation-policy)
- [20260522_1417 — coherence cleanup](#20260522_1417--coherence-cleanup)
- [20260522_1253 — script and task inventory capability](#20260522_1253--script-and-task-inventory-capability)
- [20260522_1246 — tool-stack architecture documentation](#20260522_1246--tool-stack-architecture-documentation)
- [20260522_1234 — Archcore initialization in main workflow](#20260522_1234--archcore-initialization-in-main-workflow)
- [20260522_1200 — Archcore preflight auto-init](#20260522_1200--archcore-preflight-auto-init)
- [20260522_1147 — local preflight opt-in policy](#20260522_1147--local-preflight-opt-in-policy)
- [20260522_1100 — preflight template CLI compatibility](#20260522_1100--preflight-template-cli-compatibility)
- [20260522_1045 — package coherence pass](#20260522_1045--package-coherence-pass)
- [20260522_0930 — CHANGELOG governance integration](#20260522_0930--changelog-governance-integration)
- [20260522_0900 — initial navigation module](#20260522_0900--initial-navigation-module)

## 20260523_1045 — fix: Archcore candidate report completion gate

Converted Archcore promotion candidate reporting from workflow guidance into an explicit completion gate.
Future `bootstrap`, `navigation-add`, and `refresh` runs with `.archcore/` present must verify
`ARCHCORE_PROMOTION_CANDIDATES.md`, read or section-check it before final response, and confirm
that no `.archcore/adr/`, `.archcore/rules/`, `.archcore/specs/`, `.archcore/guides/`, or
`.archcore/plans/` content files were created outside `promote` mode.

Also updated the Repomix template to include `ARCHCORE_PROMOTION_CANDIDATES.md` by default so the
candidate report is present in generated governance context.

### Files changed

- `SKILL.md` — quality checklist now requires Archcore candidate report verification and promotion-safety checks
- `patterns/archcore-routing.md` — added completion gate for candidate report and no-promotion validation
- `templates/repomix.config.json` — includes `ARCHCORE_PROMOTION_CANDIDATES.md`

## 20260523_0000 — feat: Archcore promotion candidate reporting

Added Archcore promotion candidate reporting to `bootstrap` and `refresh` modes. After
`archcore init`, the skill inspects governance files and emits `ARCHCORE_PROMOTION_CANDIDATES.md`
— a grouped, sourced list of durable content candidates (adr, rules, specs, guides, plans).
No `.archcore/` content files are written during bootstrap or refresh. Only `promote` mode
creates `.archcore/` content (direct user instruction also triggers promote).

**Extraction heuristics added to `patterns/archcore-routing.md`:** two-part test (durability
signal + normative language); category-specific rules for adr/rules/specs/guides/plans;
exclusion list (TODOs, session notes, unmarked SCRATCHPAD, CHANGELOG as direct source,
generated files, inherited parent rules, stale roadmap items).

**Design basis:** dual Codex consultation (2026-05-22) via codex-bridge MCP. See
[`docs/fix-archcore-bootstrap-seeding-20260522_2331.md`](fix-archcore-bootstrap-seeding-20260522_2331.md).

### Files changed

- `patterns/archcore-routing.md` — full replacement with core principle, extraction heuristics, exclusion table, candidate report format
- `SKILL.md` — Archcore init section expanded with promotion candidate reporting subsection; promote mode row updated
- `templates/AI_NAVIGATION.md` — `ARCHCORE_PROMOTION_CANDIDATES.md` row added to project context files table
- `AI_NAVIGATION.md` — row added to context map table; heuristic validation note added to Archcore routing block
- `README.md` — promote mode description updated; Archcore tool-stack bullet updated
- `ARCHITECTURE.md` — Archcore section updated with two-phase description; flow diagram updated
- `context-map.yaml` — `generated_output` key added under `guidance_patterns`
- `templates/context-map.yaml` — `ARCHCORE_PROMOTION_CANDIDATES.md` added to `authority_order`, `planning.read`, and `governance.read`

## 20260522_1755 — fix: embedded justfile fallback + deploy templates/ and patterns/ to installed copy

### Fixed

- `SKILL.md` — added `#### justfile — embedded fallback` block after "Task safety labels" section. Provides a 4-task minimal justfile (`default`, `audit-scripts`, `preflight`, `lint-md`) when `templates/justfile` is unavailable. Mirrors the existing embedded-fallback pattern already used for `context-preflight.sh` and `scripts/README.md`.

### Deployed

- `~/.claude/skills/skill-ai-it/templates/` — synced all 7 template files from canonical source. Previously the installed copy only contained `SKILL.md`; templates/ was never deployed.
- `~/.claude/skills/skill-ai-it/patterns/` — synced all 4 pattern files from canonical source.

### Root cause

During `/skill-ai-it bootstrap` on `invoice-finance-analyst`, the justfile was skipped on first pass. Investigation showed the installed skill (`~/.claude/skills/skill-ai-it/`) contained only `SKILL.md` with no `templates/` or `patterns/` subdirectories. The skill tried to use `templates/justfile`, found it absent, had no embedded fallback to fall back to, and silently skipped the step. The canonical source always had `templates/justfile`; it was a deploy omission.

---

## 20260522_1807 — feat: markdown quality rules enforced during file creation/update

Added "Markdown quality rules" section to Phase 4 of SKILL.md. Rules applied to every `.md` file created or updated by this skill:

- Naming: time-bound files use `<slug>-YYYYMMDD_hhmm.md`; stable entrypoints unchanged; metadata timestamps use `YYYYMMDD_hhmm`
- TOC: required for files over 100 lines; `## Contents` heading; placed immediately after main `#` heading; updated in same pass when editing
- Links: references in README/index files must be markdown links; metadata fields naming files render as links
- Quality pass: fix malformed lists and stale headings in same pass

Authority: [`/Volumes/Data/_ai/governance/categories/markdown-guide.md`](/Volumes/Data/_ai/governance/categories/markdown-guide.md)

---

## 20260522_1900 — remove: mise removed from skill entirely

### Removed

- **`templates/mise.toml`** — deleted. Skill no longer ships or generates mise files.
- All mise references removed from: `SKILL.md`, `README.md`, `ARCHITECTURE.md`, `AGENTS.md`, `AI_NAVIGATION.md`, `context-map.yaml`, `templates/AI_NAVIGATION.md`, `templates/context-map.yaml`, `templates/AGENTS-navigation-block.md`, `templates/scripts-README.md`, `templates/context-preflight.sh`, `templates/repomix.config.json`, `patterns/script-task-audit-checklist.md`.
- mise initialization section removed from `SKILL.md`.
- mise step [5/6] removed from `templates/context-preflight.sh`; steps renumbered to [1/5]–[5/5].
- mise from Phase 1 inventory table, Phase 4 file creation table, detection order, mode behaviors.

### Why

mise is no longer a concept this skill knows about. `just` is the task runner. Target projects that use other runners (Taskfile.yml, Makefile, package.json) are still detected and respected. The skill does not generate, detect, or route through mise in any form.

---

## 20260522_1800 — refactor: just-preferred task-runner strategy replaces mise-first

### Changed

- **`templates/justfile`** — new file added to templates/. Lightweight task catalog with `inventory`, `audit-scripts`, `preflight`, and `lint-md` recipes. Used when no existing task runner is present and the project does not require mise's env/version features.
- **`templates/mise.toml`** — demoted to optional env/tool-version template. Added header comments making role explicit: "prefer justfile → scripts/README.md → mise.toml".
- **`templates/scripts-README.md`** — execution policy rewritten. Preferred order: existing canonical runner → `just` → `scripts/README.md` → other runners → raw scripts. Task inventory examples changed to `just inventory` / `just audit-scripts`.
- **`templates/AGENTS-navigation-block.md`** — rule 9 updated: justfile first in inspect order, `just` preferred, mise only when project uses mise, mise not default task runner.
- **`templates/repomix.config.json`** — added `"Justfile"` (capital J) to include list alongside `"justfile"`.
- **`templates/AI_NAVIGATION.md`** — Script and Task Navigation section rewritten: justfile first in 8-item read order, just-preferred execution guidance.
- **`templates/context-map.yaml`** — scripts and automation routing: justfile first, updated rules (respect canonical runner, prefer justfile for new catalogs, mise only when already present).
- **`AI_NAVIGATION.md`** (package-level) — Script and Task Navigation: same just-preferred order. Context map table: added `templates/justfile` row; updated `templates/mise.toml` description.
- **`context-map.yaml`** (package-level) — scripts/automation routing: justfile first, updated rules. `generated_templates` routing: added `templates/justfile`.
- **`SKILL.md`** — Phase 1 inventory table: added `justfile`/`Justfile` row, updated `mise.toml` row description. Phase 4 file creation table: added `justfile` row (bootstrap only), updated `mise.toml` row to "create only when explicitly requested or tool/env management clearly needed". Detection order rewritten (8 items, justfile first). Bootstrap mode: prefer justfile for new catalogs, mise only when explicitly needed. Navigation-add mode: route to existing runner first. Refresh mode: respect existing runner, don't silently convert.
- **`README.md`** — Key rules: mise-first wording replaced with just-preferred. Package layout: added `templates/justfile`. Tool stack section: "mise tasks" entry replaced with "just / task runners" entry plus separate "mise (env/version management)" entry. Authority order updated.
- **`ARCHITECTURE.md`** — Flow diagram: script/task inventory layer updated. Source-of-truth direction diagram updated. Script and Task Inventory Layer section rewritten: justfile as preferred, existing runner priority, mise as env/version tool, agent preference order documented.
- **`AGENTS.md`** (package-level) — task catalog inspect order updated: justfile first. just-preferred and mise-optional rules added.

### Why

The previous strategy made mise the canonical runnable task catalog by default. This was heavier than necessary for projects that do not need mise's env/version management features. `just` is simpler, widely available, and better suited for lightweight project task catalogs. The refactor makes just the preferred new-project default while preserving full mise support for projects that already use it.

### Constraints honored

- mise support not removed.
- just not made mandatory — existing canonical runners always take priority.
- No existing project task runners silently converted.
- Archcore, Graphify, and Repomix behavior unchanged.
- Repeat-safety contract intact.
- Spec source: `docs/replace-mise-with-just-20260522_1652.md`.

---

## 20260522_1700 — fix: scripts/README.md update obligation added to navigation block

### Fixed

- `templates/AGENTS-navigation-block.md`: added rule 12 — "When adding, modifying, or removing scripts or tasks, update `scripts/README.md` to reflect the change — purpose, inputs, outputs, safety label, and idempotency."
- `SKILL.md` embedded AGENTS.md fallback: same rule 12 added.

### Why

Rule 11 ("identify which governance files must be updated") was too vague to reliably trigger `scripts/README.md` maintenance when scripts change. Without an explicit rule, agents would create/modify scripts without updating the catalog, causing silent drift. Rule 12 makes the update obligation specific and actionable. This closes the write-side of the circular dependency: rule 9 covers reading before running; rule 12 covers writing after changing.

### Also

- `openbb/AGENTS.md` managed block: rule 12 propagated to the live target project.

## 20260522_1643 — fix: scripts/README.md creation in refresh mode

### Fixed

- `SKILL.md` file creation table: `Refresh` column for `scripts/README.md` changed from "update managed inventory blocks only" to "create from template if scripts/tasks exist and file missing; update managed blocks if exists". Previously, refresh mode would only update an existing file, never creating it — leaving a gap where script navigation rules pointed to a file that the refresh would not create.
- `SKILL.md` Script/task inventory mode behavior: `refresh` entry updated to match the file creation table fix.

### Why

AGENTS.md navigation block (rule 9) tells agents to inspect `scripts/README.md` when present, but refresh mode never created the file if it was missing. Any project that received the navigation block via refresh but had no pre-existing `scripts/README.md` would have agents follow a pointer to a file that did not exist. Discovered when OpenBB received navigation rules but no `scripts/README.md` was created.

## 20260522_1434 — full coherence sweep

### Changed

- `README.md`: added TOC (118 lines, governance compliance); updated tool stack from "three optional" to "four project-context tools"; updated Graphify and Repomix bullet descriptions to reflect active invocation.
- `ARCHITECTURE.md`: added TOC (134 lines, governance compliance).
- `SCRATCHPAD.md`: updated current state, open items, recent decisions, and session history to reflect all changes from this session.
- All coherence checks verified: SKILL.md three-section Phase 4, active tool invocation policy, preflight mise step, CHANGELOG TOC completeness, `.gitignore` hygiene, required files and terms present.

### Notes

- No content drift found in `AGENTS.md`, `AI_NAVIGATION.md`, `context-map.yaml`, `templates/AI_NAVIGATION.md`, or `templates/context-map.yaml` — those files were already coherent.
- `slurp-chat` skill not installed; session state captured manually in `SCRATCHPAD.md`.

## 20260522_1432 — ARCHITECTURE.md tool-stack update for active CLI roles

### Changed

- `ARCHITECTURE.md` Graphify section: updated from passive description to active required tool — `graphify update .` is invoked on every `bootstrap`, `navigation-add`, and `refresh` run; Graphify is now listed as required for full skill operation.
- `ARCHITECTURE.md` Repomix section: updated to reflect active invocation — runs `repomix --config repomix.config.json` on every active-mode run; creates config from template if missing.
- `ARCHITECTURE.md` flow diagram: renamed "Generated support layer" to "Active context generation (CLIs invoked when available)" showing `graphify update .` and `repomix --config` as explicit CLI steps; added `mise install + mise tasks` to the Script/task inventory layer.

### Notes

- These changes align `ARCHITECTURE.md` with the policy changes made in the tool-stack auto-invocation entry above.

## 20260522_1431 — tool-stack auto-invocation policy

### Changed

- `SKILL.md` Repeat-Safety Contract rule 9: updated to state that Graphify and Repomix are actively run when their CLIs are available; outputs remain disposable support, not canonical truth.
- `SKILL.md` file creation table: added `Graphify / graphify-out/` row (`run if CLI available` for bootstrap/navigation-add/refresh); updated `repomix.config.json` row (`initialize if CLI available`); updated `mise.toml` row (`initialize if CLI available and no task runner canonical`).
- `SKILL.md`: added `### Graphify initialization and refresh` section — run `graphify update .` on every active-mode run; initializes if `graphify-out/` missing.
- `SKILL.md`: added `### Repomix initialization and refresh` section — create config from template if missing, run on every active-mode run.
- `SKILL.md`: added `### mise initialization` section — create `mise.toml` from template during bootstrap if CLI available and no task runner canonical.
- `templates/context-preflight.sh`: added step `[5/6] Checking mise task catalog` — runs `mise install` and `mise tasks` if `mise.toml` or `.mise/tasks/` present; renumbered all steps from `/5` to `/6`.

### Notes

- Graphify refresh on every skill rerun was explicitly requested; previously Graphify was passive (generated-output-only policy).
- mise was the only tool-stack item absent from the preflight; now all four (Archcore, Graphify, Repomix, mise) are covered.

## 20260522_1417 — coherence cleanup

### Changed

- `SKILL.md` Phase 4: split `### Always-created files` into three clear sections:
  `### Always-created files` (README.md, AGENTS.md, CLAUDE.md, SCRATCHPAD.md, CHANGELOG.md),
  `### Conditionally-created files` (ARCHITECTURE.md, CONVENTIONS.md, ROADMAP.md, AI_NAVIGATION.md,
  context-map.yaml, repomix.config.json, .graphifyignore, memory-bank/, scripts/README.md, mise.toml),
  `### Optional/generated support files` (summary table of explicit-request-only and generated artifacts).
- `SKILL.md` Phase 4: added inline stubs for ARCHITECTURE.md, CONVENTIONS.md, ROADMAP.md,
  scripts/README.md, and mise.toml/.mise/tasks/ under Conditionally-created files.
- `README.md`: added `SCRATCHPAD.md` to package layout tree.
- `AI_NAVIGATION.md`: added `SCRATCHPAD.md` row (Low authority) to context map table.
- `SCRATCHPAD.md`: marked script inventory / `mise tasks` open item as resolved (implemented 2026-05-22).
- `templates/mise.toml`: updated Python version comment from `3.12` to `3.14`.
- Root hygiene: moved `codex_prompt_fix_skill_ai_it_changelog_governance.md` to `docs/archive/`.
- Root hygiene: confirmed `SKILL.md.bak` already removed from earlier session.
- Root hygiene: removed `.DS_Store` from package root.
- Added `.gitignore` with `.DS_Store`, `.remember/logs/`, `graphify-out/`, `.ai-context/` entries.

### Notes

- Generated by coherence cleanup pass following audit in `docs/review-coherence-audit-20260522_1401.md`.
- `templates/AI_NAVIGATION.md`, `templates/context-map.yaml`, `templates/AGENTS-navigation-block.md`,
  `context-map.yaml`, and `AI_NAVIGATION.md` were already correct and required no changes.
- Navigation and context-map surfaces were verified after the cleanup; only required drift fixes were applied.

## 20260522_1253 — script and task inventory capability

### Added

- Added optional script/task inventory capability using `mise.toml` and `.mise/tasks/` as the executable source of truth when present.
- Added `templates/scripts-README.md` as the human/agent-readable script inventory template.
- Added `templates/mise.toml` as the default optional task catalog template.
- Added `patterns/script-task-audit-checklist.md` for repeat-safe task/script inventory audits.
- Added script/task navigation and context-map routing for `mise`, task runners, raw scripts, and automation safety.

### Changed

- Updated README, ARCHITECTURE, SKILL orchestration, AGENTS guidance, navigation templates, context-map templates, and Repomix packing rules for scripts and automation.
- Clarified safety handling for uncataloged, destructive, review-required, and unknown-safety tasks.

## 20260522_1246 — tool-stack architecture documentation

### Added

- Added `ARCHITECTURE.md` to explain the skill package architecture and the roles of Archcore, Graphify, and Repomix.

### Changed

- Updated `README.md`, `SKILL.md`, `AI_NAVIGATION.md`, and `context-map.yaml` so `ARCHITECTURE.md` is part of the maintained package navigation surface.

## 20260522_1234 — Archcore initialization in main workflow

### Changed

- Moved Archcore initialization into the main `SKILL.md` workflow so rerunning the skill can create `.archcore/` when the `archcore` CLI is available.
- Updated the Archcore pattern and README to distinguish allowed `archcore init` setup from governed Archcore content edits.

### Notes

- `audit` mode remains read-only unless the user asks for changes; bootstrap, navigation-add, and refresh initialize Archcore when possible.

## 20260522_1200 — Archcore preflight auto-init

### Changed

- Updated the optional local preflight template and embedded fallback to run `archcore init` automatically when the Archcore CLI exists and `.archcore/` is missing.

### Notes

- Local preflight scripts remain explicit opt-in artifacts.

## 20260522_1147 — local preflight opt-in policy

### Changed

- Changed `scripts/context-preflight.sh` generation from default/useful behavior to explicit request only.
- Clarified that generic preflight behavior is maintained in `skill-ai-it`, not in repo-local generated scripts.
- Updated generated README pointers and quality checks so local preflight scripts do not become a second source of truth.

### Notes

- Existing project-local preflight scripts should be audited and proposed for update only when the operator asks to keep them.

## 20260522_1100 — preflight template CLI compatibility

### Changed

- Updated `templates/context-preflight.sh` and the embedded fallback to avoid treating missing `.archcore/` as a failed Archcore setup.
- Replaced stale `graphify .` guidance with `graphify update .` for the installed Graphify CLI.
- Clarified the reusable preflight behavior so generated project scripts remain local entrypoints while generic logic stays maintained in this skill package.

### Notes

- Project-specific generated scripts may still add local anchor checks or local command adaptations.

## 20260522_1045 — package coherence pass

### Changed

- Aligned external managed-block markers with the documented `<!-- BEGIN skill-ai-it:navigation -->` / `<!-- END skill-ai-it:navigation -->` convention.
- Updated context preflight fallback and template checks to include `CHANGELOG.md`.
- Reconciled package templates and embedded fallback content for governance/navigation consistency.

### Notes

- `SKILL.md.bak` was intentionally ignored during this pass.

## 20260522_0930 — CHANGELOG governance integration

### Changed

- Promoted `CHANGELOG.md` to a first-class governance file for both the skill package and generated project governance.
- Updated `SKILL.md`, package governance files, templates, and drift-audit pattern to route, read, and update `CHANGELOG.md`.
- Fixed the `SKILL.md` SCRATCHPAD/CHANGELOG section ordering so each governance file has its own valid section.

### Notes

- `CHANGELOG.md` is now treated as a durable package/project history ledger and should be appended on meaningful bootstrap, navigation-add, refresh, audit, or promote runs.

## 20260522_0900 — initial navigation module

### Added

- AI navigation/context-routing module.
- Repeat-safe operating modes:
  - `bootstrap`
  - `navigation-add`
  - `refresh`
  - `audit`
  - `promote`
- External template package:
  - `templates/AI_NAVIGATION.md`
  - `templates/context-map.yaml`
  - `templates/repomix.config.json`
  - `templates/AGENTS-navigation-block.md`
  - `templates/context-preflight.sh`
- External pattern package:
  - `patterns/archcore-routing.md`
  - `patterns/memory-bank-structure.md`
  - `patterns/drift-audit.md`
- Skill package governance files:
  - `README.md`
  - `AGENTS.md`
  - `CLAUDE.md`
  - `AI_NAVIGATION.md`
  - `context-map.yaml`

### Changed

- Expanded skill from initial bootstrap only to repeat-safe governance/navigation maintenance.
- Added template precedence and fallback rules.
- Restored conditional templates for:
  - `ARCHITECTURE.md`
  - `CONVENTIONS.md`
  - `ROADMAP.md`
