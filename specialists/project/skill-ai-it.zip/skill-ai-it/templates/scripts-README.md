# Script Inventory

This file describes runnable scripts, task runners, and automation entrypoints in this project.

<!-- BEGIN skill-ai-it:scripts -->

## Execution Policy

- Prefer the existing canonical task runner for this project.
- Prefer `just <task>` when a `justfile` is present.
- Do not run scripts marked `destructive`, `review-required`, or `unknown` without review.
- Do not assume arbitrary files under `scripts/` are safe.
- If a script is missing from this inventory, inspect it before use and update or propose an inventory entry.
- Secrets must not be documented here as values. Document only secret names and where they are expected to come from.

## Preferred Execution Order

1. Existing canonical task runner (whichever is established for this project)
2. `just --list` / `just <task>`
3. `scripts/README.md`
4. Other task runners: `Taskfile.yml`, `Makefile`, `package.json`
5. Raw scripts under `scripts/` after inspection

## Task Inventory

| Task / Script | Purpose | Inputs | Outputs | Safety | Idempotent | When to use |
|---|---|---|---|---|---|---|
| `just inventory` | Lists available tasks and this inventory. | `justfile`, `scripts/README.md` | Console output | `safe` | Yes | First check before running project automation |
| `just audit-scripts` | Checks for obvious script/catalog drift. | `scripts/`, `scripts/README.md` | Console output | `safe` | Yes | During refresh/audit or before agent automation |
| `just preflight` | Runs safe local validation checks. | Project files | Console output | `safe` | Yes | Before edits, commits, or handoff |

## Raw Script Inventory

| Script | Purpose | Inputs | Outputs | Safety | Idempotent | When to use |
|---|---|---|---|---|---|---|
| `_TBD_` | `_TBD_` | `_TBD_` | `_TBD_` | `unknown` | `_TBD_` | Inspect before use |

## Safety Labels

| Label | Meaning |
|---|---|
| `safe` | Read-only or low-risk repeatable operation |
| `review-required` | Needs human review before execution |
| `destructive` | Deletes, overwrites, migrates, deploys, or changes external state |
| `external-network` | Calls external services or APIs |
| `modifies-files` | Writes to repo/project files |
| `requires-secrets` | Requires secret values |
| `requires-credentials` | Requires authenticated local/session credentials |
| `long-running` | May take significant time |
| `unknown` | Not yet classified; do not run without inspection |

## Maintenance Rules

- Keep this file aligned with:
  - `justfile`
  - `Taskfile.yml`
  - `Makefile`
  - `package.json`
  - actual files under `scripts/`
- Prefer managed block updates for generated sections.
- Preserve manually written notes unless explicitly replacing them.
- When removing a script, remove or mark its inventory entry stale.
- When adding a script, document purpose, inputs, outputs, safety, idempotency, and when to use it.

## Notes

Add project-specific caveats here.

<!-- END skill-ai-it:scripts -->
