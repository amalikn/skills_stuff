# Evaluation procedure

Use a fresh credential-free client context. Run explicit invocation, implicit realistic task, unrelated negative control and the mixed replacement task from `scenarios.md`; record client/version,
package version, symlink target, prompt, loaded skill, first reference, observability, verdict and a redacted evidence locator.

For every pass, check the scenario’s prohibited conclusion. If loader observation is unavailable, record `uncertain`, not pass. Discovery failure blocks release.

For write-back scenarios verify one of the five classifications and source, product/app version, evidence type, falsifier and redaction. For upgrade scenarios verify supported-extension adjustment,
superseded patch retirement and reviewed patch rebase with rollback.
