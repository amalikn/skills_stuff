"""Offline contract checks for the skill-openwisp guidance package."""

from __future__ import annotations

import re
import unittest
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = {
    "SKILL.md", "CHANGELOG.md", "sources.yaml", "compatibility.yaml",
    "references/identity-and-registration.md", "references/passive-ingestion.md",
    "references/verification-and-troubleshooting.md", "references/health-alerts-notifications.md",
    "references/topology-and-foss.md", "references/capability-extension.md",
    "references/customisation-and-upgrades.md", "references/evolution-and-write-back.md",
    "tests/requirements.txt", "tests/test_package_contract.py", "tests/scenarios.md",
    "tests/eval-procedure.md",
}
FORBIDDEN_NAMES = {
    "manifest.json", "RUNBOOK.md", "upstream-links.md", "paginate.py", "fingerprint.py",
    "netjson_mapping.py", "agents", "scripts",
}
CLAIM_FIELDS = {"id", "statement", "kind", "evidence_status", "lifecycle", "applies_to", "evidence", "reference", "test"}
CLAIM_KINDS = {"generic_invariant", "tested_pattern", "worked_example"}
EVIDENCE = {"VERIFIED_PRIMARY", "VERIFIED_SECONDARY", "UNVERIFIED", "USER_STATED"}
LIFECYCLES = {"current", "superseded"}
LAYERS = {"observed_install", "official_documented", "offline_contract", "api_accepted", "worker_processed", "metric_persisted", "recent_point", "operator_visible"}
RESULTS = {"pass", "fail", "pending_live_test", "stale", "incompatible"}
COMPAT_FIELDS = {"id", "product", "product_version", "components", "observed_at", "evidence_locator", "validation_layer", "result"}


def _load(path: Path) -> dict:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise AssertionError(f"{path.name} must contain a YAML mapping")
    return value


def _assert_safe_text(text: str, path: str = "fixture") -> None:
    patterns = {
        r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----": "private key delimiter",
        r"(?im)^authorization:\s*(?!Bearer DUMMY_TOKEN_DO_NOT_USE$).+": "live authorization header",
        r"(?im)^(?:password|token|api[_-]?key)\s*[:=]\s*(?!DUMMY_TOKEN_DO_NOT_USE\s*$).+": "non-dummy credential assignment",
        r"(?i)\b(?:teleport|communitywifi|apn)\.(?:au|com)\b": "production domain",
        r"(?:captures/|/captures/|transcript|raw[-_ ]?capture)": "raw capture/transcript reference",
        r"\b(?:10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.)": "unsafe private-address example",
    }
    for pattern, reason in patterns.items():
        if re.search(pattern, text):
            raise AssertionError(f"{path}: {reason}")


def _validate_compatibility(document: dict) -> set[str]:
    rows = document.get("environments")
    if not isinstance(rows, list) or not rows:
        raise AssertionError("compatibility.yaml requires non-empty environments")
    ids: set[str] = set()
    for row in rows:
        if not isinstance(row, dict) or not COMPAT_FIELDS <= set(row):
            raise AssertionError("compatibility row missing required fields")
        if row["id"] in ids or not re.fullmatch(r"[a-z0-9][a-z0-9-]*", str(row["id"])):
            raise AssertionError("compatibility IDs must be unique kebab-case")
        ids.add(row["id"])
        if row["validation_layer"] not in LAYERS or row["result"] not in RESULTS:
            raise AssertionError("invalid compatibility layer or result")
        if row["validation_layer"] == "observed_install" and row["result"] == "pass" and "operator-visible" in str(row).lower():
            raise AssertionError("observed install cannot prove operator-visible behaviour")
    return ids


class PackageContractTests(unittest.TestCase):
    def test_required_tree_and_no_deferred_helpers(self) -> None:
        actual = {path.relative_to(ROOT).as_posix() for path in ROOT.rglob("*") if path.is_file()}
        self.assertTrue(REQUIRED <= actual, sorted(REQUIRED - actual))
        self.assertFalse({path.name for path in ROOT.rglob("*")} & FORBIDDEN_NAMES)

    def test_entrypoint_routes_every_reference(self) -> None:
        content = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        frontmatter = re.match(r"^---\n(.*?)\n---\n", content, re.S)
        self.assertIsNotNone(frontmatter)
        metadata = yaml.safe_load(frontmatter.group(1))
        self.assertEqual(set(metadata), {"name", "description"})
        self.assertEqual(metadata["name"], "skill-openwisp")
        self.assertTrue(metadata["description"].strip())
        self.assertNotIn("TODO", content.upper())
        for reference in sorted(path for path in REQUIRED if path.startswith("references/")):
            self.assertIn(reference, content)

    def test_claim_and_compatibility_schema(self) -> None:
        sources = _load(ROOT / "sources.yaml")
        environment_ids = _validate_compatibility(_load(ROOT / "compatibility.yaml"))
        claims = sources.get("claims")
        self.assertIsInstance(claims, list)
        self.assertTrue(claims)
        ids: set[str] = set()
        scenario_text = (ROOT / "tests/scenarios.md").read_text(encoding="utf-8")
        for claim in claims:
            self.assertTrue(CLAIM_FIELDS <= set(claim), claim)
            self.assertNotIn(claim["id"], ids)
            ids.add(claim["id"])
            self.assertIn(claim["kind"], CLAIM_KINDS)
            self.assertIn(claim["evidence_status"], EVIDENCE)
            self.assertIn(claim["lifecycle"], LIFECYCLES)
            self.assertTrue(set(claim["applies_to"]) <= environment_ids)
            self.assertTrue((ROOT / claim["reference"]).is_file())
            self.assertIn(claim["test"], scenario_text)
            self.assertRegex(claim["statement"], r"\.$")
            self.assertNotRegex(claim["statement"].lower(), r"api acceptance.*(?:complete|working).*monitoring")
            if claim["lifecycle"] == "superseded":
                self.assertTrue(claim.get("superseded_by"))
        self.assertIn("0.1.0", (ROOT / "CHANGELOG.md").read_text(encoding="utf-8"))

    def test_content_is_redacted_and_routes_are_real(self) -> None:
        for path in ROOT.rglob("*"):
            if path.is_file() and path.suffix in {".md", ".yaml", ".txt"}:
                _assert_safe_text(path.read_text(encoding="utf-8"), path.relative_to(ROOT).as_posix())

    def test_negative_fixtures_prove_sensitive_content_checks(self) -> None:
        for unsafe in ("Authorization: Bearer real-token", "password=not-a-dummy", "-----BEGIN PRIVATE KEY-----"):
            with self.assertRaises(AssertionError):
                _assert_safe_text(unsafe)

    def test_negative_fixture_proves_evidence_rung_check(self) -> None:
        bad = {"environments": [{"id": "bad", "product": "OpenWISP", "product_version": "1", "components": [], "observed_at": "2026-10-01", "evidence_locator": "x", "validation_layer": "observed_install", "result": "pass", "note": "operator-visible graph"}]}
        with self.assertRaises(AssertionError):
            _validate_compatibility(bad)


if __name__ == "__main__":
    unittest.main()
