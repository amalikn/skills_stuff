# Passive ingestion

Use a vendor-neutral observation model for closed-firmware devices: schema version, captured-at UTC time, stable device identity, interface/resource observations, source and freshness. Represent `up`
as true, false or unknown; omit absent values rather than fabricating zero or false; retain named units and sampling time for counters.

Map only fields the target NetJSON DeviceMonitoring version supports. Keep custom fields in a named extension namespace with a consumer test. A future-neutral mapper is a contract, not runnable v0.1
code: reject malformed required identity/counters before network activity and keep ingestion time distinct from source observation time. Claim O-C05.
