# Verification and troubleshooting

Use this evidence ladder: `API accepted → worker processed → Metric persisted → recent time-series point → health evaluated → operator-visible graph`.

For each rung, collect direct evidence, identify the next dependency, and record what is not proven. An accepted payload can still fail in workers; a persisted metric can be stale; a recent point can
lack health evaluation; a health state can lack a rendered graph. Start diagnosis at the first unproven rung, checking worker state, module/version/settings consistency, timestamp freshness and the
target consumer. Claim O-C03.
