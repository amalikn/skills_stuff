# Customisation and upgrades

Record Django effective settings, custom metric registration, notifications, worker consistency, component/image versions and supported add-ons. A running image proves its observed version only; it
does not prove a custom ingestion or graph path.

Prefer configuration and supported add-ons, then narrow overlays/shims. Track direct core patches with source/base version, affected behaviour, test and rollback. On upgrade, compare upstream
behaviour, adjust supported APIs/settings, migrate/test, verify operator-visible behaviour and retain rollback. Do not blindly replay a core patch: retire it when superseded or manually review/rework
it when still required. Claims O-C04 and O-C09.
