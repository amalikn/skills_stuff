# Capability extension

State the operator-visible outcome and acceptance test. Search OpenWISP core, official modules, Django/settings extension mechanisms, relevant NTC/FOSS, external monitoring/discovery tooling and only
then a custom adapter if the preceding levels cannot satisfy the result.

For each lower level, document why the preceding supported option is insufficient. Recheck maintenance, license, compatibility, reachability and extension seam before recommendation. Closed firmware
is not OpenWrt-native management. Claim O-C08.
