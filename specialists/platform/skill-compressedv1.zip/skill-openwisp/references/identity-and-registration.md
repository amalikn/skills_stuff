# Identity and registration

Separate logical monitoring identity, registration identity and physical hardware identity. Adopt known records idempotently, prevent duplicate registration, and make physical replacement mapping
explicit so consumers can retain the logical identity where policy permits.

`hardware_id` is a versioned worked case, not a universal key. Verify its exact model/API semantics for the installed version and distinguish client/API acceptance from server-side registration
effects. Registration settings are documented but deployment-effective settings and device support still need verification. Claims O-C01 and O-C02.
