# Topology and complementary FOSS

Treat topology observations as evidence with source, time, vantage, confidence, conflicts and stale state. NetJSON NetworkGraph concepts and OpenWISP Network Topology may be relevant when
version-supported; verify them before making precise claims. Keep observed edges distinct from inventory intent.

Research complementary discovery, graph, correlation and visualisation FOSS through supported seams, not a static ranking. An installed topology module does not prove an operational graph pipeline,
and the UNC graph slice is proposed rather than implemented. Claim O-C07.
