# Health, alerts and notifications

Model observed health separately from the policy that interprets it, alert evaluation, suppression/correlation and the transport that delivers a notification. A notification integration is not
automatically the policy engine.

Define freshness, thresholds, ownership, suppression and escalation before choosing where logic belongs. The UNC host-side alarm approach is a worked architecture pattern, not an OpenWISP requirement.
Claim O-C06.
