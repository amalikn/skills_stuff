# Changelog

## 0.1.0 — 2026-10-01

- Added claims O-C01 through O-C10, scenarios O-S01 through O-S15, and offline contract O-T01.
- Recorded observed image/module environment rows without promoting them to ingestion behaviour.
- No migrations or retirements.
