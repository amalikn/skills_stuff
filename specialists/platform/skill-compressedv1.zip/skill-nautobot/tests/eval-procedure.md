# Evaluation procedure

Use a fresh credential-free client context. Run explicit invocation, implicit realistic task, unrelated negative control and the mixed lifecycle task from `scenarios.md`; record client/version,
package version, symlink target, prompt, loaded skill, first reference, observability, verdict and short redacted evidence locator.

For every pass, check the scenario’s prohibited conclusion. For an unobservable loader, record `uncertain`, not a pass. A discovery failure blocks release.

For write-back scenarios, verify one of the five classifications and require source, product/app version, evidence type, falsifier and redaction. For upgrade scenarios, verify supported-extension
adjustment, superseded core patch retirement and reviewed core-patch rebase with rollback rather than replay.
