# Staged onboarding

Use the sequence `observe → corroborate identity → stage → resolve ambiguity → approve → promote`. Preserve source, time, vantage and confidence for every observation.

Corroborate identity with independent evidence such as serial, stable management identity, inventory record or physical record. Contradictory sightings enter an ambiguity queue; they do not overwrite
an existing intended record. Make plan/dry-run output reviewable, keep the approval boundary explicit, and promote only the reviewed outcome.

Brownfield migration is evidence reconciliation, not a bulk import shortcut. Claim N-C05.
