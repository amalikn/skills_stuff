# Capability extension

State the desired operator outcome and acceptance test first. Research Nautobot core; installed or maintained apps and NTC tooling; supported seams of those components; compatible external FOSS; then
from-scratch work only if the preceding levels are insufficient.

Useful research starting points include Golden Config, Nornir, Secrets Providers, DNS Models, Design Builder, SSoT, Device Onboarding, Device Lifecycle Management, Capacity Metrics, netutils,
diffsync, schema-enforcer, pynautobot, nautobot-ansible, nornir-nautobot, ntc-templates, Netdisco, LibreNMS, OpenNMS and lldpd. They are not blanket recommendations. Recheck maintenance, license,
compatibility, reachability and supported seams for the task at hand. Claim N-C10.
