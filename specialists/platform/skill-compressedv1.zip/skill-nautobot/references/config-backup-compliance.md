# Configuration backup and compliance

Treat collection, redaction, equality/fingerprint comparison, compliance assessment, restore verification and deployment as separate controls. A backup does not authorize a push, and a matching
fingerprint does not prove a safe restore.

Keep credentials and sensitive configuration out of logs and skill material. The UNC HMAC digest pattern is a worked case only: it supports keyed equality comparison, not identity, authorization or
tamper proof, and its threat model and key lifecycle remain project-owned. Claim N-C09.
