# Apps, Jobs and validation

Start with core capabilities, then installed maintained apps, then supported extension points. Assess a custom app, validator, Job or external runner against the operator-visible acceptance test and
least privilege boundary.

Validate UI and worker execution separately: permissions, environment, queue reachability and transaction behaviour can differ. Choose fail-open or fail-closed deliberately for each validator and
document the effect of worker failure. Recheck Job interfaces when upgrading; 3.2 introduced execution-interface changes. Claim N-C08.
