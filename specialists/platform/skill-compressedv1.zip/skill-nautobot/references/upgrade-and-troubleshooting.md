# Upgrade and troubleshooting

Maintain a project-local extension register: purpose, exact upstream versions, extension form, source/base version, affected hook/API/model, retrofit steps, test, rollback and status. Distinguish
configuration, supported app/plugin/Job/API adapter, overlay/shim and core patch.

For every upgrade, compare compatibility, effective behaviour and operator-visible outcome. Never blindly replay a core patch: inspect new upstream implementation, decide whether it is still needed,
review/rework it, test the exact and adjacent contracts, and test rollback. The initial observed environment is recorded in `compatibility.yaml`; it is not a broad support range. Claims N-C04 and
N-C11.
