# API and writers

Make reader traversal deterministic: request a stable ordering or cursor guarantee, bound the page count, track page identity and stable object IDs, and stop on a repeated page, duplicate identity,
missing page or changing-data ambiguity. Do not silently deduplicate a broken result set.

Separate reader and writer paths. The caller supplies authentication and authorization; a reusable routine never embeds credentials. A writer names its identity, reads enough state to be idempotent,
plans changes, supports dry-run, reports conflicts, and closes rather than guessing when expected identity or ownership does not match.

Relationship and REST response details vary with release and query options, so verify the exact endpoint/model before coding against it. Claim N-C03.
