# Authority and modelling

Nautobot holds accepted intent, not every observation. Identify the owner and write authority for each field before modelling it; reserve imported or collected fields for their declared writer.

Model physical geography with Location hierarchy, administrative ownership with Tenant where it is meaningful, and IPAM uniqueness with Namespace. A Namespace is appropriate when otherwise identical
addresses are genuinely separate; the site-scoped Namespace pattern is a worked case, not a default.

Use devices, interfaces, prefixes and IP addresses for their native meanings. Model a durable cross-object fact with a Relationship; use a custom field for a bounded attribute on an existing model;
create a custom model only when it has its own identity, lifecycle, permissions and relations. Reconfirm model/API details against the version-matched official documentation. Claims N-C01 and N-C02.

Separate lifecycle status from observed health. A device can remain Active while an observation is stale or critical; an explicit policy, not telemetry alone, decides whether lifecycle changes.
