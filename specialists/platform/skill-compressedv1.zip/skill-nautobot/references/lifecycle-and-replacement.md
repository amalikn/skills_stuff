# Lifecycle and replacement

Separate the logical service position from the physical unit occupying it. Record replacement mapping, custody handoff, actor authentication, audit history and downstream identifiers so an asset swap
does not accidentally create a new logical service.

A QR label can help identify an object and link a record; it does not authenticate a technician. Require the project’s approved actor/authentication control for custody or lifecycle actions.
Preserve
stable monitoring and consumer identities deliberately during replacement. Claim N-C06.
