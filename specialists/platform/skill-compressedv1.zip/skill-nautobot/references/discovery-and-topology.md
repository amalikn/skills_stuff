# Discovery and topology

SNMP, LLDP/CDP, FDB, REST/device APIs, SSH/CLI, ARP/neighbour state, DHCP, DNS and inventory are evidence sources with different failure modes. Store source, timestamp, vantage, endpoint identity,
confidence, conflicts and staleness where material.

Keep observed topology separate from accepted intended topology. A conflicting edge is evidence to investigate, not permission to overwrite intent. Resolve whether a result is stale, asymmetric,
misidentified or genuinely drift before promotion.

The UNC Step 9 discovery correlator is a proposed worked case, not an implemented platform capability. Claim N-C07.
