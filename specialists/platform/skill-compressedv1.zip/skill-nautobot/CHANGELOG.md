# Changelog

## 0.1.0 — 2026-10-01

- Added claims N-C01 through N-C12, scenarios N-S01 through N-S14, and offline contract N-T01.
- Recorded the observed Nautobot 3.2.3 environment and version-sensitive verification boundary.
- No migrations or retirements.
