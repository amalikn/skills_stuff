---
name: skill-openwisp
description: >-
  Guide OpenWISP work involving device registration, passive closed-firmware and NetJSON ingestion, monitoring metrics and graph failures, health and alerts, topology, Django customisation, upgrades,
  missing capabilities, and complementary FOSS evaluation; use for monitoring observations rather than inventory lifecycle unless the task actually crosses both platforms.
---

# OpenWISP

## Role and non-goals

Use OpenWISP for registration, monitoring, metrics, health, notifications, OpenWrt-oriented controller capabilities, topology/NetJSON integration where version-supported, and extensions through
Django, settings, modules and APIs.
Do not assume a closed-firmware device has native configuration control or turn a project-specific shim into product behaviour.

## Read, write, and evidence boundaries

**HTTP/API acceptance is only the first evidence rung.**
Keep `API accepted → worker processed → Metric persisted → recent time-series point → health evaluated → operator-visible graph` separate.
Obtain project authorization for writes, retain source/version/evidence, and never infer a later rung from an earlier one.
Keep observation source, timestamp, freshness and unit semantics available to the consuming policy.
Do not embed client credentials, customer topology, or equipment-specific commands in reusable guidance.

## Route the task

| Task | Read first |
| --- | --- |
| Logical identity, adoption, duplicate prevention, replacement | [references/identity-and-registration.md](references/identity-and-registration.md) |
| Passive observations, NetJSON and closed-firmware metrics | [references/passive-ingestion.md](references/passive-ingestion.md) |
| Accepted payload, worker, storage, freshness and graph triage | [references/verification-and-troubleshooting.md](references/verification-and-troubleshooting.md) |
| Health, policy, suppression, correlation and notification transport | [references/health-alerts-notifications.md](references/health-alerts-notifications.md) |
| Observed topology, NetJSON NetworkGraph and complementary FOSS | [references/topology-and-foss.md](references/topology-and-foss.md) |
| Missing capability, modules, supported seams and FOSS | [references/capability-extension.md](references/capability-extension.md) |
| Django settings, metrics, workers, overlays and upgrades | [references/customisation-and-upgrades.md](references/customisation-and-upgrades.md) |
| Reusable learning capture and engagement closeout | [references/evolution-and-write-back.md](references/evolution-and-write-back.md) |

## Verify version-sensitive facts

Before asserting a current endpoint, model field, setting, timestamp format, supported module or release behaviour, inspect version-matched official documentation and record source/date in
[sources.yaml](sources.yaml).
Read [compatibility.yaml](compatibility.yaml) as a bounded evidence ledger; an observed image or module version does not prove ingestion or a graph.
Record unknowns as unknown rather than extrapolating a support range.

## Search before building

```text
desired operator outcome
  ↓ existing OpenWISP core capability
  ↓ installed or maintained product modules and relevant NTC tooling
  ↓ supported extension points of those components
  ↓ compatible external FOSS and its supported seams
  ↓ from-scratch component only when the acceptance test still cannot be met
```

At every downward transition, explain why the preceding level cannot meet the acceptance test.
Recheck maintenance, license, compatibility, reachability and supported extension mechanisms; do not maintain a static best-tools ranking.
Prefer the narrowest supported seam and cover the behaviour it relies on with a regression test.

## Project and equipment boundary

Keep exact customer, site and device state in its governing project.
Route vendor commands, OIDs and device access details to equipment expertise; do not include credentials or device-specific operations here.
For a cross-platform task, load another skill only when the task actually crosses its ownership boundary.

## Mandatory closeout

End every engagement by classifying learning as `no_new_reusable_learning`, `reusable_candidate`, `project_only`, `equipment_only`, or `contradicts_existing_claim`.
For a validated reusable result, follow [references/evolution-and-write-back.md](references/evolution-and-write-back.md); do not rely on chat memory.
