# Capability extension

## Decision rubric

Define the operator-visible outcome and acceptance test first. Evaluate OpenWISP core; Monitoring, Controller, Notifications, and Network Topology modules; documented Django/settings and NetJSON
extension seams; compatible external FOSS or collectors; and only then a narrow custom adapter. At each transition, state why the preceding supported choice cannot meet the result.

Assess maintenance, licence, target image and Python compatibility, effective settings, worker/network reachability, data model and source-of-truth semantics, permissions, operational load,
testability, upgrade/rollback cost, and the consumer that proves success. A module with the right model but no reachable collector is not an operational fit. A data store that accepts an observation
does not thereby become the inventory authority.

## Integration boundary

OpenWISP Controller is oriented around supported configuration backends and OpenWrt-adjacent conventions. Closed firmware may fit passive monitoring while lacking a supported configuration or
firmware-control path. Preserve that boundary instead of building an implicit device controller. Use NetJSON only at the documented seam and version; use external collectors/adapters when they have
clear ownership and a testable contract. Claim O-C08.
