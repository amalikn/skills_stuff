# Health, alerts and notifications

## Separate controls

Observed metric values, freshness/staleness, health derivation, threshold policy, alert state, suppression/correlation, and notification transport are different controls. A transport integration can
deliver a notification without deciding the correct threshold; a metric may be fresh but outside policy; a stale metric may be operationally more important than a low value.

Define the owner of each policy, its freshness window, threshold/tolerance, escalation, acknowledgement, and suppression rules before selecting a module or external engine.
Treat root-cause
correlation separately from presentation: suppressing downstream symptoms is safe only when the likely upstream cause and recovery behavior remain visible.

## Project-derived diagnostic lesson

The project observed that collector or transport failure can produce fleet-wide symptom noise. Its host-side cause-aware alarm design is a worked architecture pattern, not an OpenWISP requirement.
The reusable lesson is to distinguish transport/collector evidence from device symptom evidence and avoid declaring every downstream device independently broken. Claim O-C14.

## Acceptance

Test current and stale data, threshold crossing, recovery, duplicate suppression, root-cause visibility, notification delivery failure, and operator acknowledgement independently.
A delivered message is
not proof that health was computed correctly, and a critical state is not proof that the transport succeeded. Claim O-C06.
