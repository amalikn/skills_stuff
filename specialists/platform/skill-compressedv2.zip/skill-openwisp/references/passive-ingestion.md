# Passive ingestion

## Neutral observation boundary

For closed firmware, treat OpenWISP as a passive monitoring consumer unless a supported control path is separately proven. Normalize vendor output into a versioned neutral observation before NetJSON
DeviceMonitoring mapping: stable identity, source, captured-at UTC time, sampling time, interfaces/resources, units, counters, freshness, and declared vendor semantics. Keep vendor-specific naming,
wireless interpretation, and transport detail at the adapter boundary rather than laundering them into a platform model.

Represent interface state as up, down, or unknown. Omit a field that was not observed; do not fabricate zero or false. Represent down only when the source explicitly reports an administratively or
operationally disabled interface. Counters require non-negative values, named units, and the interval or sampling time needed to interpret change. Ingestion time and source observation time are
different facts, especially for backfill.

## Mapping limits

Map only fields supported by the target version-pinned NetJSON DeviceMonitoring schema. Put required richer fields behind a named top-level extension with a consumer test; the existence of an extension
does not promise stock charts or health rules. The project found that richer point-to-multipoint and high-frequency radio data may not fit a standard wireless representation naturally. Preserve that
lossiness as a design decision rather than inventing semantics. Claim O-C13 is the project-derived known/unknown/down pattern.

## Verification

Reject malformed required identity, counters, and ambiguous timestamps before any network action. A later mapper must prove offline transformation, accepted payload, worker processing, Metric
persistence, recent point, health evaluation, and graph separately. This v0.1 skill contains guidance only, not a mapper. Claim O-C05.
