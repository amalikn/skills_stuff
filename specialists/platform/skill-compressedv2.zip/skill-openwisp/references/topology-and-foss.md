# Topology and complementary FOSS

## Graph evidence model

Treat topology input as an observation with source, time, vantage, endpoint identity, confidence, conflict state, and freshness. NetJSON NetworkGraph and RECEIVE-style ingestion concepts can carry
observed edges, but an observed graph is not intended inventory. Preserve parallel, disputed, and stale edges rather than normalizing them into a single asserted path.

When a task crosses the seam, make provenance visible in the graph or its review record: which collector asserted the edge, what it could observe, and why an operator accepted or rejected it.
Rendering is a consumer of graph data, not evidence that discovery, reconciliation, or intent promotion works.

## Capability boundary

OpenWISP Network Topology and complementary FOSS can be evaluated for collection, diffing, correlation, or rendering through supported seams. An installed module does not create a working pipeline;
verify its version, effective settings, ingestion path, worker reachability, persistence, and consumer view. The project NetworkGraph integration is proposed architecture, not deployed capability.
Claim O-C07.
