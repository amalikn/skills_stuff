# Verification and troubleshooting

## Evidence ladder

Use this ordered ladder and start at the first unproven rung:

| Rung | Direct proof | Failure clue | Inspect next | Does not prove |
| --- | --- | --- | --- | --- |
| API accepted | Response and validated request record | HTTP error or validation rejection | Payload/schema/identity | Worker processing |
| Worker processed | Task log/result for the same identity and timestamp | Queue backlog, task exception, or missing consumer action | Worker image, settings, queue, dependency | Metric persistence |
| Metric persisted | Matching Metric record or storage write | Record absent or wrong identity/type | Registration, mapping, transaction | Fresh time-series point |
| Recent time-series point | Query returns a point within declared freshness | Old timestamp, wrong unit, retention or storage delay | Timestamp, backend, retention, sampling | Health evaluation |
| Health evaluated | Policy evaluated that current point | Stale/unknown state or policy not run | Threshold, freshness, scheduled check | Operator-visible graph |
| Operator-visible graph | Authorized UI/API view renders expected series | Empty chart or wrong filter | Consumer query, permissions, chart config | Broader monitoring acceptance |

HTTP 200 is therefore insufficient. A worker can accept a task but fail before useful storage; a Metric object can exist while its time-series data is stale; a fresh point can miss a health policy;
and a healthy state can still have no rendered graph. These were project diagnostic distinctions, not a claim that each later rung has passed for the observed Monitoring 1.3 installation.

## Troubleshooting discipline

Correlate every inspection by stable identity, metric name/type, source timestamp, and worker/request trace. Check version and effective settings across API and worker processes before changing a
mapping. Timestamp normalization or freshness errors can produce misleading health, and graph absence can be downstream of successful persistence. Record the first failed rung, evidence, falsifier,
and next safe action; do not promote a lower rung to a higher one. Claims O-C03 and O-C12.
