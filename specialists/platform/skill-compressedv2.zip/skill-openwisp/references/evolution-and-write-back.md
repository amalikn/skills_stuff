# Evolution and write-back

At engagement closeout classify the result as `no_new_reusable_learning`, `reusable_candidate`, `project_only`, `equipment_only`, or `contradicts_existing_claim`.

Useful candidates include module behaviour, ingestion limitations, worker issues, metric behaviour, API/version constraints, extension seams and upgrade regressions. A validated reusable result
updates the focused reference, `sources.yaml`, relevant compatibility evidence, a scenario/regression and `CHANGELOG.md` when canonical source is writable.

If source is unavailable, read-only or evidence unresolved, create a durable redacted candidate in the engaging project’s governed documentation area with source, version, evidence type and
falsifier.
Do not generalize one success or create noise for a normal no-op. Claim O-C10.
