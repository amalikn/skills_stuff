# Identity and registration

## Identity model

Separate logical identity, hardware identity, registration identity, and monitoring identity. A logical service can persist through a physical replacement only when the replacement mapping is explicit;
a physical serial or MAC must not be silently reused as the service identity. Choose a stable identifier, state who owns it, and determine which downstream consumers need continuity.

Registration is an adoption decision as well as a create decision. Match an existing record only with corroborated identity evidence; otherwise stage the ambiguity and stop. Duplicates, moved units,
factory-reset hardware, and a replacement can look similar to an automated client. Record whether the operation adopted, created, linked, deactivated, or rejected a record, together with the relevant
group/site mapping and rollback action.

## Worked version-bound lesson

The project OpenWISP 1.3 path used a dashless inventory UUID in `hardware_id` through server-side model operations because the tested REST surface did not supply the required hardware-identity
semantics. The UI label was not proof of the API field's meaning. This is a worked version-specific pattern, not a universal OpenWISP registration recipe; check target model/API behavior and
effective settings before relying on it. Claim O-C11.

## Acceptance and failure clues

An accepted registration request is not proof that the intended record, group mapping, monitoring identity, or deduplication policy took effect. Investigate duplicate identity, stale registration,
unexpected group, UI/API label mismatch, server-side validation, and replacement mapping separately. Acceptance requires one authoritative logical identity, explicit hardware association, idempotent
adoption/create behavior, and a reviewable replacement path. Claims O-C01 and O-C02.
