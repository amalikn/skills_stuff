# Customisation and upgrades

## Effective configuration

Record Django settings, custom metric registration, notification types, import order, extension registration, worker configuration, image tag, installed module versions, migrations, and process
state. Verify the effective settings in every process that uses them; a dashboard and worker can start with different settings, a stale process, or a different import path. Where process identifiers
or pidfiles are available, use them as diagnostic evidence, not as a universal deployment requirement.

The observed image tag and installed Python module versions are separate coordinates. A running image proves only its observed identity, not that custom ingestion, settings propagation, or graphing
works. Claim O-C15.

## Upgrade path

Prefer settings and supported add-ons, then narrow overlays/shims. Treat direct core patches as explicit debt with original base, affected behavior, migration/import consequences, tests, rollback,
and a retirement condition. On upgrade, compare upstream behavior and extension APIs; re-register custom metrics/notifications where needed; migrate; test API and worker paths; verify the
operator-visible outcome; and retain rollback.

If upstream supersedes a patch, test the replacement and retire the patch with history. If a patch remains necessary, review and rework it against the new code rather than replaying it. Import/start
success is not functional compatibility, and functional compatibility is not operator-visible acceptance. Claims O-C04 and O-C09.
