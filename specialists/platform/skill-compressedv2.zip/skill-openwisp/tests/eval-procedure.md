# Evaluation procedure

Use a fresh credential-free client context. Run explicit invocation, implicit realistic task, unrelated negative control and the mixed replacement task from `scenarios.md`; record client/version,
package version, symlink target, prompt, loaded skill, first reference, observability, verdict and a redacted evidence locator.

For every pass, check the scenario’s prohibited conclusion. If loader observation is unavailable, record `uncertain`, not pass. Discovery failure blocks release.

For write-back scenarios verify one of the five classifications and source, product/app version, evidence type, falsifier and redaction. For upgrade scenarios verify supported-extension adjustment,
superseded patch retirement and reviewed patch rebase with rollback.

## Knowledge-value rubric

For passive monitoring, the response must distinguish API accepted, worker processed, Metric persisted, recent point, health evaluated, and operator-visible graph without inferring a later rung from
an earlier one. It must preserve closed-firmware limits, known/unknown/down semantics, and the distinction between logical and hardware identity. For a passed evaluation, record which of these
decision points was directly observable; a polished generic monitoring answer is not enough.
