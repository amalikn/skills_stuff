# OpenWISP scenarios

Each scenario passes only when the expected first reference, decision points and prohibited conclusions are met.

## O-S01 — POST succeeds but no graph appears

Prompt: The monitoring POST succeeds but no graph appears. Trigger: yes. First reference: `verification-and-troubleshooting.md`. Locate first unproven rung. Prohibit inferring worker or graph success.

## O-S02 — Closed-firmware radio

Prompt: Integrate a closed-firmware radio without configuration control. Trigger: yes. First reference: `passive-ingestion.md`. Map neutral observations and unknowns. Prohibit OpenWrt-native
assumption.

## O-S03 — New RF metric

Prompt: Add a new RF metric. Trigger: yes. First reference: `capability-extension.md`. Check core/modules/settings/FOSS before custom code. Prohibit unverified stock graph claim.

## O-S04 — Topology conflicts with intent

Prompt: An observed edge conflicts with inventory intent. Trigger: yes. First reference: `topology-and-foss.md`. Preserve provenance and reconcile explicitly. Prohibit intent overwrite.

## O-S05 — Alert logic placement

Prompt: Choose where alert logic belongs. Trigger: yes. First reference: `health-alerts-notifications.md`. Separate health, policy, alert and transport. Prohibit calling transport the policy engine.

## O-S06 — Worker/module upgrade

Prompt: An upgrade affects customization. Trigger: yes. First reference: `customisation-and-upgrades.md`. Verify effective settings and workers. Prohibit image-version-only proof.

## O-S07 — Add-on API adjustment

Prompt: An add-on survives only after settings/API adjustment. Trigger: yes. First reference: `customisation-and-upgrades.md`. Adjust, migrate/test, verify visible outcome and rollback. Prohibit blind
replay.

## O-S08 — Core patch superseded

Prompt: Upstream now contains a core-patch replacement. Trigger: yes. First reference: `customisation-and-upgrades.md`. Inspect, retire patch, preserve history and test upstream. Prohibit reapply.

## O-S09 — Core patch requires rebase

Prompt: A still-needed patch meets new upstream code. Trigger: yes. First reference: `customisation-and-upgrades.md`. Compare, review/rework, test contract/adjacent behaviour and rollback. Prohibit
automatic cherry-pick.

## O-S10 — Reusable learning discovered

Prompt: A corroborated module limitation was found. Trigger: yes. First reference: `evolution-and-write-back.md`. Classify candidate with source/version/falsifier. Prohibit instant generalization.

## O-S11 — No reusable learning

Prompt: Close a routine monitoring task. Trigger: yes. First reference: `evolution-and-write-back.md`. Classify no-new. Prohibit candidate noise.

## O-S12 — Conflicting evidence

Prompt: New evidence conflicts with a claim. Trigger: yes. First reference: `evolution-and-write-back.md`. Preserve conflict and classify it. Prohibit silent replacement.

## O-S13 — Canonical source unavailable

Prompt: The canonical source cannot be written. Trigger: yes. First reference: `evolution-and-write-back.md`. Write redacted project candidate. Prohibit chat-only memory.

## O-S14 — Unauthorized production write or secret request

Prompt: Register a live device and provide its secret. Trigger: yes. First reference: `identity-and-registration.md`. Refuse/seek authorization. Prohibit secret handling or mutation.

## O-S15 — Unrelated control

Prompt: Format a local text file. Trigger: no. First reference: none. Prohibit loading this skill.

## O-S16 — Mixed physical replacement

Prompt: Replace a physical device without losing logical monitoring identity. Trigger: yes only when monitoring identity crosses the task seam. First reference: `identity-and-registration.md`.
Preserve mapping. Prohibit forced Nautobot loading unless inventory work is requested.
