---
Title: OpenWISP documentation snapshots
Category: source-index
Status: current
Authority: Official OpenWISP documentation snapshots
Scope: Local evidence copies used to maintain version-sensitive `skill-openwisp` guidance
Last reviewed: 2026-10-01
Summary: Curated official OpenWISP pages retained locally with source URLs, version scope, and checksums; they are evidence copies, not a second routing layer.
---

## OpenWISP documentation snapshots

These files are official-documentation snapshots fetched on 2026-10-01. The release page establishes the 26.09 component context. The Controller and Monitoring settings pages are explicitly current
documentation: use them for general configuration principles only, never as proof that an observed 1.3 installation has identical settings or runtime behavior.

| File | Official source | Version scope | SHA-256 |
| --- | --- | --- | --- |
| [openwisp-26.09-release-notes.html](openwisp-26.09-release-notes.html) | `https://openwisp.io/docs/dev/releases/26.09.html` | Versioned OpenWISP 26.09 release context | `b6b61bc1378da1df700f14785d6cccc3e055eccb644eea978ff4437f6d533a68` |
| [openwisp-controller-current-settings.html](openwisp-controller-current-settings.html) | `https://openwisp.io/docs/dev/controller/user/settings.html` | Current generic Controller settings; not 1.3 runtime proof | `7215fe2f490f63e47cb844d90e7b048fb9f983fa8af72f72596e79b7cb472d79` |
| [openwisp-monitoring-current-settings.html](openwisp-monitoring-current-settings.html) | `https://openwisp.io/docs/dev/monitoring/user/settings.html` | Current generic Monitoring settings; not 1.3 runtime proof | `a82bb92c16bc39d498b0c304a5dde1b6a2e6ebc3117d5c3f31e8d327025b400a` |

Do not edit snapshots to change their content. Replace a file only by re-fetching the named source, recalculating its checksum, and updating this index and any affected claim evidence.
