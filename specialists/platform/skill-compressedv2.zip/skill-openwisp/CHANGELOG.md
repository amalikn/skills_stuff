# Changelog

## 0.1.0 — 2026-10-01

- Added claims O-C01 through O-C15, scenarios O-S01 through O-S16, and the deterministic package contract.
- Recorded observed image/module rows, the explicit pending Monitoring evidence ladder, and local official-documentation snapshots.
- Hardened registration, passive ingestion, rung-by-rung verification, alert correlation, topology, capability, and upgrade guidance without promoting pending live behavior.
- No migrations or retirements.
