---
name: skill-nautobot
description: >-
  Guide Nautobot work involving source-of-truth modelling, inventory, IPAM, relationships, Jobs and apps, APIs, staged onboarding, configuration compliance, discovery, topology, and upgrade-safe
  extensions; use when designing missing capabilities or evaluating complementary FOSS, not for telemetry, metric ingestion, graph failures, health alerts, or monitoring observations unless the task
  chiefly concerns Nautobot intended inventory or lifecycle.
---

# Nautobot

## Role and non-goals

Use Nautobot primarily for intended network source-of-truth modelling, inventory, IPAM, relationships, lifecycle workflows, validation, Jobs/apps and integration APIs.
Do not treat telemetry monitoring as its default responsibility, or describe a project worked case as product behaviour.

## Read, write, and evidence boundaries

Read-only investigation may produce observations; it does not authorize an inventory mutation.
Observed discovery does not automatically become intended inventory, and transient health must not silently redefine lifecycle state.
Obtain project-specific authorization before every write, keep the writer identity and idempotence contract explicit, and fail closed on ambiguity.
Keep an observation's source, time, vantage and confidence when it may affect a later decision.
Do not embed client credentials, customer topology, or equipment-specific commands in reusable guidance.

## Route the task

| Task | Read first |
| --- | --- |
| Ownership, IPAM, relationships, custom data models | [references/authority-and-modeling.md](references/authority-and-modeling.md) |
| API traversal, deterministic readers, safe writers | [references/api-and-writers.md](references/api-and-writers.md) |
| Brownfield discovery, identity, staging and approval | [references/staged-onboarding.md](references/staged-onboarding.md) |
| Replacement, custody, labels and identity continuity | [references/lifecycle-and-replacement.md](references/lifecycle-and-replacement.md) |
| Discovery sources, conflicts and topology evidence | [references/discovery-and-topology.md](references/discovery-and-topology.md) |
| Apps, Jobs, validators, workers and permissions | [references/apps-jobs-validation.md](references/apps-jobs-validation.md) |
| Backup, redaction, compliance, restore and deployment | [references/config-backup-compliance.md](references/config-backup-compliance.md) |
| Missing capability, providers, NTC and complementary FOSS | [references/capability-extension.md](references/capability-extension.md) |
| Upgrade preflight, extension register and incident triage | [references/upgrade-and-troubleshooting.md](references/upgrade-and-troubleshooting.md) |
| Reusable learning capture and engagement closeout | [references/evolution-and-write-back.md](references/evolution-and-write-back.md) |

## Verify version-sensitive facts

Before asserting a current endpoint, model field, Job/app interface, or release behaviour, inspect version-matched official documentation and record the source/date in [sources.yaml](sources.yaml).
Use [compatibility.yaml](compatibility.yaml) only for its stated environment and evidence rung; an observed install is not behavioural proof.
Record unknowns as unknown rather than extrapolating a supported version range.

## Search before building

```text
desired operator outcome
  ↓ existing Nautobot core capability
  ↓ installed or maintained product apps/modules and relevant NTC tooling
  ↓ supported extension points of those components
  ↓ compatible external FOSS and its supported seams
  ↓ from-scratch component only when the acceptance test still cannot be met
```

At every downward transition, state why the preceding level cannot meet the acceptance test.
Check current maintenance, license, compatibility, reachability and extension support; do not maintain a static best-tools ranking.
Prefer the narrowest supported seam and cover the behaviour it relies on with a regression test.

## Project and equipment boundary

Keep customer, site and exact device state in its governing project.
Route device commands, OIDs and vendor-specific behaviour to the appropriate equipment expertise rather than copying them here.
For a cross-platform task, load another skill only when the task actually crosses its ownership boundary.

## Mandatory closeout

End every engagement by classifying learning as `no_new_reusable_learning`, `reusable_candidate`, `project_only`, `equipment_only`, or `contradicts_existing_claim`.
For a validated reusable result, follow [references/evolution-and-write-back.md](references/evolution-and-write-back.md); do not rely on chat memory.
