# Evaluation procedure

Use a fresh credential-free client context. Run explicit invocation, implicit realistic task, unrelated negative control and the mixed lifecycle task from `scenarios.md`; record client/version,
package version, symlink target, prompt, loaded skill, first reference, observability, verdict and short redacted evidence locator.

For every pass, check the scenario’s prohibited conclusion. For an unobservable loader, record `uncertain`, not a pass. A discovery failure blocks release.

For write-back scenarios, verify one of the five classifications and require source, product/app version, evidence type, falsifier and redaction. For upgrade scenarios, verify supported-extension
adjustment, superseded core patch retirement and reviewed core-patch rebase with rollback rather than replay.

## Knowledge-value rubric

For onboarding, the response must distinguish observation, candidate identity, corroboration, ambiguity, Staged review, and promotion; one identifier must not be treated as sufficient. For topology,
it must state what LLDP/CDP, FDB, ARP, DHCP, API/SSH, and inventory can and cannot prove. For writers, it must name stable ordering, repeated/changing-page failure, ownership, dry-run, and
fail-closed behavior. For a passed evaluation, record which of these decision points was directly observable; a polished generic answer is not enough.
