# Discovery and topology

## Evidence is not topology authority

Represent an observation with source, capture time, vantage point, endpoint identities, confidence, parser or collector version where material, conflict state, and freshness. The same link seen from
two ends is stronger evidence than a single assertion, but it is still observed state until a governed review promotes it.

| Source | Useful for | Cannot prove alone |
| --- | --- | --- |
| LLDP/CDP | A neighbour report from a specific vantage | An end-to-end physical path or both ends' agreement |
| FDB | A learned MAC on a port | Direct attachment or a stable cable |
| ARP/neighbour state | An IP/MAC sighting | A physical link or current ownership |
| DHCP | A recent lease association | Present topology or device identity |
| Device API or SSH | A vendor-owned association | Cross-device physical truth |
| Inventory | Approved intended arrangement | Current observation |

SNMP, DNS, and CLI evidence fit the same contract: state what was observed and from where, rather than turning a parser result into a permanent edge. Parallel links, asymmetric reports, and an
identity collision must remain explicit candidates, not collapsed into one attractive graph edge.

## Promotion and modelling

Keep physical topology, logical service topology, and monitoring association separate. A conflicting observation can indicate stale state, a one-sided report, a collector fault, a changed path, or a
real intent drift. Investigate those possibilities before changing accepted inventory. A custom Relationship is suitable for a durable relation between existing objects; the project's Wireless Link
object is a worked example where the native model was insufficient, not a product-wide prescription. Claim N-C15.

The project Step 9 correlator and rendering slice remain proposed architecture only. An installed model, a discovery feed, or a drawn graph does not prove reconciliation is implemented. Acceptance is
a traceable observation, conflict handling, reviewer decision, and separately recorded intended edge. Claim N-C07.
