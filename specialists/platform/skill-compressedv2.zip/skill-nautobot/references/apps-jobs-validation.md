# Apps, Jobs and validation

## Choose the execution seam

Use core behavior when it meets the acceptance test and ownership boundary. Use a maintained app when it is version-compatible and operationally reachable. Use a supported custom app or API extension
when the domain model or permissions belong inside Nautobot. Use a Job for an operator-triggered or schedulable task whose worker can safely reach every required dependency. Keep execution outside
Nautobot when the network path, credentials, retry model, or operational blast radius cannot be safely provided to its workers.

The project Device Onboarding, SSoT, and DiffSync assessment is an example, not a blanket verdict: a feature is not a valid solution merely because Nautobot supports its model if the worker cannot
reach the network or device path required to execute it. Reassess reachability, driver fit, and authority in each deployment. Claim N-C16.

## Validation and diagnostics

UI execution and worker execution may differ in settings, permissions, environment variables, queues, network route, database transaction, and extension registration. Test the path the operator will
actually use. A validator must deliberately fail open or fail closed: fail-open permits questionable data under an outage; fail-closed can stop legitimate work. State which result is acceptable and
how it is surfaced.

Diagnose by asking whether the Job was registered, queued, claimed, able to authenticate, able to resolve its dependencies, authorized to write the target field, and able to return a visible result.
Service writers need least-privilege permissions and an explicit field-ownership contract. A UI success is not proof of a worker success.

Nautobot 3.2 changed Job invocation patterns; import or startup success does not prove functional compatibility, and functional compatibility does not prove an operator-visible outcome. Upgrade tests
must exercise the exact Job, validator, queue, and rollback path. Claim N-C08.
