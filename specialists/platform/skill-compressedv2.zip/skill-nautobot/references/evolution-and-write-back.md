# Evolution and write-back

At engagement closeout classify the result as `no_new_reusable_learning`, `reusable_candidate`, `project_only`, `equipment_only`, or `contradicts_existing_claim`.

For validated reusable knowledge and a writable canonical source, update the focused reference, `sources.yaml`, relevant compatibility evidence, a scenario/regression and `CHANGELOG.md`. A single
successful instance is a candidate until it has sufficient source, version, evidence and falsifier.

If canonical source is unavailable, read-only or unresolved, create a durable redacted candidate in the engaging project’s governed documentation area with source, version, evidence type, falsifier
and private information removed. Do not create noise for a normal no-op and do not rely on chat memory. Claim N-C12.
