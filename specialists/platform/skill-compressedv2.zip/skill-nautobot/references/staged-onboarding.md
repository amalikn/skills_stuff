# Staged onboarding

## State machine

Use `observation → identity candidates → corroboration → ambiguity or Staged object → review → promotion`. Preserve source, capture time, vantage, confidence, and the facts used to reach each state.
An observation is never an instruction to create or overwrite production inventory.

One identifier is insufficient: labels move, addresses are reused, serials may be absent, and a service name can survive a hardware replacement. Corroborate with independent evidence such as a stable
management identity, serial, physical record, existing inventory, or an authenticated handoff. When facts disagree, retain the candidates and contradiction rather than selecting the most convenient
match. An ambiguity queue is a valid result and a reason to stop automation.

## Brownfield and greenfield

For brownfield onboarding, reconcile what exists against intended inventory and represent safe candidates as Staged. A discovered name is an observation; an intended name is an approved convention.
Do not silently rename an existing intended object to match a poll result. Handle moved units, replacements, duplicate identities, and stale records as separate review cases with a visible proposed
action and rollback path. Dry-run output should show create, adopt, link, rename, skip, and ambiguity actions distinctly.

Greenfield provisioning begins with approved intent and controlled creation; brownfield onboarding begins with uncertain evidence. Treating them as the same bulk-import workflow is a common source of
accidental duplicate records and ownership loss.

## Promotion acceptance

Promote only after a reviewer accepts the corroborated identity, field ownership, intended name, Location/Namespace/Tenant placement, lifecycle state, and downstream linkage. Stop when identity is
ambiguous, the writer lacks ownership, a pre-existing record has contradictory authority, or the plan would create a duplicate. This is a project-derived brownfield pattern, not a promise that a
particular Nautobot workflow automates it. Claim N-C05.
