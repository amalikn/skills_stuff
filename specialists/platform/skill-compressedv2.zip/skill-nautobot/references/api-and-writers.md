# API and writers

## Reader contract

The project experienced unordered pagination that produced a distorted, incomplete object set. Stable ordering is therefore a tested reusable pattern, not decorative API hygiene. Ask the source API
for a unique stable order or use its documented cursor/snapshot guarantee, follow only its returned continuation, impose a finite page bound, and record page identity plus stable object identity.

Sorting does not create a snapshot. Stop and report ambiguity when a continuation repeats, a page fails to advance, an expected identity repeats, an identity disappears between pages, a page is empty
before completion, or the source changes during traversal. Blind deduplication can hide both missing and duplicated data, so it does not prove completeness. Retrying may be appropriate only for named,
idempotent read failures; it cannot repair changing-data semantics.

## Writer contract

Keep readers and writers separately identifiable. The caller owns authentication, authorization, base URL, retry policy, and secret delivery; reusable guidance must not embed them. A writer should
declare its service identity and owned fields, read enough existing state to decide idempotence, produce a reviewable plan, support dry-run without mutation, and report an ownership conflict rather
than overwriting another authority.

Before a write ask: Which object identity is authoritative? Which fields may this identity own? Does the desired state already exist? Does a partial failure have a safe retry? Is a mutation allowed
by the governing project? If any answer is missing, fail closed with diagnostics that distinguish authentication, permission, model validation, ownership conflict, pagination ambiguity, and transport
failure. Do not treat a successful request as evidence that downstream workers or external devices changed.

Relationship serialization, query depth, permissions, pagination, and Job/API details vary by release and query options. Confirm the exact endpoint and product version before integration code relies
on a response shape. Acceptance means the read set is complete under its stated contract and every planned write has explicit authority, identity, idempotence, and an observable outcome. Claims N-C03
and N-C13.
