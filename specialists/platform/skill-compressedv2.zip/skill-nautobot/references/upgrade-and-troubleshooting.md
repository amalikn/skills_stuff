# Upgrade and troubleshooting

## Extension register and preflight

Maintain a project-local extension register with purpose, exact upstream and Python versions, extension form, source/base version, affected model/API/setting, migrations, worker requirements,
retrofit steps, tests, rollback, and status. Distinguish configuration, supported app, Job/API adapter, overlay, and core patch. The observed environment in `compatibility.yaml` is a comparison target,
not a broad compatibility promise.

Before upgrade, read release notes and the extension register; inspect custom app compatibility, changed Job APIs, validators, migrations, settings, worker behavior, extension registration, and any
core patch. After upgrade, prove three distinct levels:

```text
import or start success
!= functional compatibility
!= operator-visible acceptance
```

A service can import while a Job no longer queues, a validator is no longer registered, a migration is incomplete, or a worker uses different settings from the UI.

## Retrofit and rollback

If upstream supplies a replacement for a patch, verify the replacement, retire the patch, preserve history, and test the new behavior. If a patch remains necessary, compare the original base to new
upstream code, review and rework it manually, test its exact and adjacent contracts, and verify rollback. Never blindly replay a patch. The same discipline applies to custom apps, Jobs, and
validators: identify whether the seam remains supported before treating a green process as a compatible extension.

Common diagnostic clues are missing apps after startup, Jobs visible in the UI but unavailable to workers, stale validators, failed migrations, or permissions changing API response shape. Claims N-C04
and N-C11.
