# Authority and modelling

## Decision model

Treat Nautobot as the record of accepted intent, not an unfiltered event store. For each object and field, name the authority, writer, evidence class, and review path before deciding where it lives.
Useful state classes are intended state, observed state, and evidence about an observation. A collector may propose an observation; it does not acquire authority to redefine intent.

Location describes physical geography and hierarchy. Tenant describes an administrative or service ownership boundary when that boundary matters. Namespace is the IPAM uniqueness boundary; it is not a
substitute for either geography or tenancy. Namespaces allow otherwise overlapping address records, and a site-scoped Namespace was a tested project solution for genuinely independent address domains,
not a universal default. Claim N-C02 is the documented model principle; the concrete split needs local justification.

## Modelling choices

Use Devices, Interfaces, Prefixes, and IP Addresses for their native meanings. A project-derived rule retained the narrowest containing Prefix mask on an address rather than defaulting every address to
`/32`; that preserves the usable routing fact but still requires validation against the local IPAM design. Do not use a host route merely to make an import convenient. Claim N-C14 is this worked
pattern, not a core Nautobot guarantee.

Use a Relationship for a durable fact between existing objects. Use a custom field for a bounded attribute whose lifecycle belongs to its existing object. Consider a custom model only when the concept
has its own identity, lifecycle, permissions, relations, and query needs. The project Wireless Link object is a worked case: native models did not adequately represent its durable semantics. It does
not prove that every radio association needs a custom model. Keep physical topology, logical service topology, and transient telemetry separate.

Keep Device Status as an approved lifecycle state. Health, freshness, signal, and reachability are observations or policy outputs; a critical observation does not silently turn an Active device into
a retired or failed lifecycle object. An explicit policy may create a review task or a controlled transition, but telemetry alone does not decide it.

Do not put secrets, raw polling payloads, high-rate time series, uncorroborated neighbour claims, or an external system's entire schema into Nautobot merely because it has an extension seam. Preserve
only the durable intent or the bounded evidence needed to govern it.

## Failure clues and acceptance

Conflicting writers, a Location used to dodge IP uniqueness, a custom field carrying an independent lifecycle, and a monitoring process overwriting Status are modelling failures. Before acceptance,
verify the object owner, write permissions, uniqueness boundary, parent Prefix/mask, relationship cardinality, lifecycle policy, and the version-specific model/API behavior actually relied on.
Claims N-C01, N-C02, and N-C14.
