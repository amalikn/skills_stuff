# Configuration backup and compliance

## Separate controls

Backup collects a recoverable representation. Compliance evaluates it against an approved policy. Deployment changes a target. Restore verification proves a backup can be used safely. These are
separate capabilities with different authorization and evidence requirements. A successful backup must not automatically authorize a push; a matching comparison must not be called a restore proof.

Redact secrets before storage, reporting, and comparison. Retain enough metadata to explain collection time, target identity, scope, and failure without placing secret-bearing configuration in a
ticket or reusable skill. Golden Config or another tool may provide collection/comparison seams, but driver support, credentials, network reachability, and target behavior remain dependencies to
verify for the installed version.

## Comparison and restoration

A project worked pattern used a keyed HMAC digest for equality comparison while avoiding plaintext retention. It can show that two values produce the same keyed digest; it is not identity,
authorization, tamper proof, or a substitute for key management. Truncation, domain separation, key rotation, leakage of low-entropy inputs, and collision tolerance are project security decisions.
Do not promote that pattern into a generic helper without a cross-project consumer and security review.

Acceptance requires a redaction review, a declared comparison scope, a known restore procedure tested in an authorized environment, and a separate deployment gate with rollback. Backup success alone,
or a hash equality result alone, is insufficient. Claim N-C09.
