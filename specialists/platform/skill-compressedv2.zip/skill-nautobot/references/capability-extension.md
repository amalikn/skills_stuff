# Capability extension

## Decision rubric

Start with an observable operator outcome and its acceptance test. Evaluate, in order: (1) Nautobot core, (2) a maintained Nautobot app, (3) an NTC library or supported integration seam, (4) a
supported custom app, Job, or API extension, (5) complementary external FOSS, and (6) a narrow custom component. At every step state why the prior option cannot meet the test; this prevents a new
framework becoming the default answer.

For every candidate assess maintenance and licence, supported Nautobot and Python versions, upgrade cadence, network reachability, source-of-truth semantics, permissions, data-model fit,
operational load, testability, rollback, and the cost of replacement. A model that fits data but cannot reach the network is not operationally fit. A tool that can collect data but overwrites intent
without ownership boundaries is not source-of-truth fit.

## Starting map, not recommendation list

Useful investigation starting points include Golden Config, Nornir, Secrets Providers, DNS Models, Design Builder, SSoT, Device Onboarding, Device Lifecycle Management, Capacity Metrics, netutils,
diffsync, schema-enforcer, pynautobot, nautobot-ansible, nornir-nautobot, ntc-templates, Netdisco, LibreNMS, OpenNMS, and lldpd. Their presence here is task-indexed awareness, not endorsement;
verify maintenance, licence, compatibility, and supported seams at the target version before selecting one.

Edit a declared source and render derived artifacts rather than editing a generated catalog. The project catalog workflow is a tested source-of-truth pattern, not a requirement of Nautobot itself.
Acceptance includes the source/derived boundary, chosen seam, permissions, upgrade test, and an operator-visible outcome. Claim N-C10 and N-C17.
