# Lifecycle and replacement

## Decision model

Separate the logical service position from the physical asset that currently occupies it. A Device record may represent one or the other only when that choice is explicit; otherwise model the
relationship and replacement history so a hardware swap does not accidentally become a new service, or erase the history of the old asset.

Plan the replacement before changing status: identify the outgoing and incoming assets, their authoritative identities, custody state, location, service relationship, monitoring identity, dependent
interfaces/IPs, and the acknowledgement that makes cutover complete. A physical move to warehouse or another site is a custody/location question, not proof of lifecycle retirement.

## Identity and audit

Preserve a stable monitoring or consumer identity only when the system's policy says it represents the logical service rather than the physical hardware. Record a replacement mapping and audit trail
instead of reusing a hardware identifier. Capture who performed or approved the handoff through the project's authenticated actor control. A QR label is an efficient lookup aid, not authentication;
a scanned label alone cannot authorize custody or lifecycle change.

## Common mistakes and acceptance

Common mistakes are overwriting the old serial, using a label as proof of actor identity, retaining stale links without an acknowledgement, and declaring a warehouse move a replacement. Acceptance is
an auditable chain from outgoing asset through custody and replacement decision to incoming asset, with downstream service/monitoring behavior verified and a rollback or exception path documented.
Claim N-C06.
