---
Title: Nautobot documentation snapshots
Category: source-index
Status: current
Authority: Official Nautobot documentation snapshots
Scope: Local evidence copies used to maintain version-sensitive `skill-nautobot` guidance
Last reviewed: 2026-10-01
Summary: Curated official Nautobot pages retained locally with source URLs, version scope, and checksums; they are evidence copies, not a second routing layer.
---

## Nautobot documentation snapshots

These files are official-documentation snapshots fetched on 2026-10-01. They support maintenance of version-sensitive claims but do not replace checking current official documentation before
asserting new product behavior. `nautobot-namespace-current-docs.html` is intentionally labelled current and supports only the general Namespace model principle, not a claim about a specific runtime.

| File | Official source | Version scope | SHA-256 |
| --- | --- | --- | --- |
| [nautobot-core-3.2.2-release-notes.html](nautobot-core-3.2.2-release-notes.html) | `https://archive.docs.nautobot.com/projects/core/en/v3.2.2/release-notes/version-3.2/` | Nautobot 3.2.2 release notes; used for the 3.2 Job-change context | `eaf96570f6d6d5a7bb033e7f5ffa4b06d3f43b53a41e0faa36a7809c0e2cdd20` |
| [nautobot-namespace-current-docs.html](nautobot-namespace-current-docs.html) | `https://docs.nautobot.com/projects/core/en/stable/user-guide/core-data-model/ipam/namespace/` | Current generic Namespace documentation; not version-matched runtime proof | `a1776c6c1495224c667f84d974a618f7e5bd6ad7ac75c4f583605d09ae81ae92` |

Do not edit snapshots to change their content. Replace a file only by re-fetching the named source, recalculating its checksum, and updating this index and any affected claim evidence.
