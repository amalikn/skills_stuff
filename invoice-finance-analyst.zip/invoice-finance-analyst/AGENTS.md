@../AGENTS.md

Title: Invoice Finance Analyst — Agent Policy
Category: agent-governance-guide
Status: current
Authority: local-supplement
Scope: Skill authoring folder for the internal-invoice-analysis skill
Last reviewed: 2026-05-21
Summary: Local agent guidance for authoring, testing, and maintaining the invoice-finance-analyst skill and its implementation scripts.

# AGENTS.md

This folder is the **canonical authoring surface** for the `internal-invoice-analysis` skill and its supporting scripts, templates, docs, and tests.

## Working rules

- The source of truth for skill behavior is `SKILL.md` inside the built skill folder. All numeric conclusions in the skill must come from Python/pandas calculations, not LLM inference.
- The source framework document is [`docs/invoice_analysis_framework.md`](docs/invoice_analysis_framework.md) — this is a **planning/research artifact** (884-line design survey), not the operational spec. Use `ARCHITECTURE.md` and `internal-invoice-analysis/SKILL.md` as the authoritative implementation references. Do not contradict the framework doc's core methodology without operator approval.
- **Hard constraint baked into the skill:** do not use external market, CPI, inflation, stock, or macroeconomic data unless the user explicitly asks for it.
- Never invent missing values, service mappings, prices, or customer IDs — flag them as exceptions instead.
- Python scripts in `scripts/` must use **Python 3.14.4** (`/opt/homebrew/opt/python@3.14/bin/python3.14`) per the parent AGENTS.md venv rule.
- If a venv is needed, place it at `/Volumes/Data/_ai/_skills/skills-working-cache/invoice-finance-analyst/venv/` — never inside this folder.
- Ephemeral runtime state (logs, pid files) goes under `/Volumes/Data/_ai/_skills/skills-runtime/invoice-finance-analyst/`.
- Internal domain for APN-related data: `apn.net.au`. Mark external senders/recipients accordingly when processing comms.
- Keep [`SETUP.md`](SETUP.md) current when adding dependencies, venv steps, or invocation patterns.
- Keep [`ARCHITECTURE.md`](ARCHITECTURE.md) current when adding or changing analysis layers.
- Follow naming convention: `<slug>-YYYYMMDD_hhmm.md` for time-bound notes and output docs.
- Do not modify source CSV files — treat all inputs as read-only.

## Canonical governance linkage

- Parent area guidance: [../AGENTS.md](../AGENTS.md)
- Cross-repo governance root: [/Volumes/Data/_ai/governance/README.md](/Volumes/Data/_ai/governance/README.md)
- Watchman event logs: [governance/watchman-events/](governance/watchman-events/) — filesystem change records for session recovery
- Watchman cheatsheet: [/Volumes/Data/_ai/governance/watchman-cheatsheet.md](/Volumes/Data/_ai/governance/watchman-cheatsheet.md)
