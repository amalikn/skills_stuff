# Source File Inventory

_Rows: 2_

| source_type      | file_name                   | file_hash                                                        |   row_count |   duplicate_row_count | null_counts_json                                                                                                                                                                                 | loaded_at           |
|:-----------------|:----------------------------|:-----------------------------------------------------------------|------------:|----------------------:|:-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------------|
| supplier_invoice | supplier_invoice_sample.csv | 9e5a9dac77658bf00dd025879ad96b84078a5e6ff0927aee7ab355b2420fc045 |           5 |                     1 | {"invoice_number": 0, "invoice_date": 0, "billing_period_start": 0, "billing_period_end": 0, "supplier_service_id": 0, "service_type": 0, "description": 1, "amount_ex_tax": 0, "tax_amount": 0} | 2026-05-21T17:23:59 |
| sales_billing    | sales_billing_sample.csv    | 4652f4d1b986a986a1b00efb9b9a2ba1d0abecc14e44b863e8e717521fe0448a |           4 |                     0 | {"customer_id": 0, "customer_name": 0, "our_service_id": 0, "billing_period_start": 0, "billing_period_end": 0, "revenue_ex_tax": 0, "cost_ex_tax": 1, "service_type": 0}                        | 2026-05-21T17:24:00 |
