# Invoice Lines — No Sales Match

_Rows: 1_

| supplier_service_id   | billing_period_start   | billing_period_end   | invoice_number   | service_type    |   amount_ex_tax | description        |
|:----------------------|:-----------------------|:---------------------|:-----------------|:----------------|----------------:|:-------------------|
| LOC000002             | 2026-01-03 00:00:00    | 2026-03-31 00:00:00  | INV-2026-03-001  | NBN Copper 25/5 |              38 | Monthly AVC charge |
