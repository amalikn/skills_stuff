# Amount Mismatches

_Rows: 1_

| supplier_service_id   | billing_period_start   |   invoice_amount_ex_tax |   sales_cost_ex_tax |   variance_abs |   variance_pct | customer_id   | exceeds_abs_tolerance   | exceeds_pct_tolerance   |
|:----------------------|:-----------------------|------------------------:|--------------------:|---------------:|---------------:|:--------------|:------------------------|:------------------------|
| LOC000003             | 2026-01-03 00:00:00    |                      52 |                  48 |              4 |       0.076923 | CUST-003      | True                    | True                    |
