# Sales Lines — No Invoice Match

_Rows: 1_

| our_service_id   | billing_period_start   | billing_period_end   | customer_id   | customer_name   | service_type   |   revenue_ex_tax |   cost_ex_tax |
|:-----------------|:-----------------------|:---------------------|:--------------|:----------------|:---------------|-----------------:|--------------:|
| LOC000005        | 2026-01-03 00:00:00    | 2026-03-31 00:00:00  | CUST-002      | Beta Pty Ltd    | NBN Fibre      |               65 |           nan |
