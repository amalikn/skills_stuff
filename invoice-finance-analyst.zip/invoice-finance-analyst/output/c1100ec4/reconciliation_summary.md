# Reconciliation Summary

_Rows: 5_

| match_status      |   row_count |   invoice_amount_total |   sales_revenue_total |   pct_of_invoice_rows |
|:------------------|------------:|-----------------------:|----------------------:|----------------------:|
| matched           |           3 |                    162 |                   200 |                   0.6 |
| invoice_only      |           1 |                     38 |                   nan |                   0.2 |
| sales_only        |           1 |                    nan |                    65 |                   0.2 |
| amount_mismatch   |           1 |                     52 |                   nan |                   0.2 |
| duplicate_removed |           1 |                    nan |                   nan |                   0.2 |
