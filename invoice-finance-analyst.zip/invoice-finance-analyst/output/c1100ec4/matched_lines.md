# Matched Lines

_Rows: 3_

| supplier_service_id   | billing_period_start   | billing_period_end   | invoice_number   | service_type      |   invoice_amount_ex_tax |   sales_revenue_ex_tax |   sales_cost_ex_tax |   variance_abs |   variance_pct |   direct_margin_ex_tax |   direct_margin_pct | customer_id   | amount_mismatch_flag   |
|:----------------------|:-----------------------|:---------------------|:-----------------|:------------------|------------------------:|-----------------------:|--------------------:|---------------:|---------------:|-----------------------:|--------------------:|:--------------|:-----------------------|
| LOC000001             | 2026-01-03 00:00:00    | 2026-03-31 00:00:00  | INV-2026-03-001  | NBN Fibre 100/20  |                      58 |                     72 |                  58 |              0 |       0        |                     14 |            0.194444 | CUST-001      | False                  |
| LOC000003             | 2026-01-03 00:00:00    | 2026-03-31 00:00:00  | INV-2026-03-001  | NBN Wireless 25/5 |                      52 |                     63 |                  48 |              4 |       0.076923 |                     11 |            0.174603 | CUST-003      | True                   |
| LOC000004             | 2026-01-03 00:00:00    | 2026-03-31 00:00:00  | INV-2026-03-001  | NBN Fibre 50/20   |                      52 |                     65 |                  52 |              0 |       0        |                     13 |            0.2      | CUST-004      | False                  |
