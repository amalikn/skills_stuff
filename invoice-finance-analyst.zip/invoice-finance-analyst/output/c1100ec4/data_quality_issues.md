# Data Quality Issues

_Rows: 3_

| source_type      | field       | issue_type       |   count | severity   | detail                                 |
|:-----------------|:------------|:-----------------|--------:|:-----------|:---------------------------------------|
| supplier_invoice | description | null_in_optional |       1 | medium     | 1 null/empty value(s) in 'description' |
| supplier_invoice | (all)       | duplicate_row    |       1 | high       | 1 exact duplicate row(s) detected      |
| sales_billing    | cost_ex_tax | null_in_optional |       1 | medium     | 1 null/empty value(s) in 'cost_ex_tax' |
