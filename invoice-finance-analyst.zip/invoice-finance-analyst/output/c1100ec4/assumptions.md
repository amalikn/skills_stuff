# Assumptions

_Rows: 5_

| assumption_key                            | value                                    | rationale                                                                       | source   |
|:------------------------------------------|:-----------------------------------------|:--------------------------------------------------------------------------------|:---------|
| tolerance.abs                             | 0.02                                     | Mirrors APN house rounding standard (DISCOUNT_TOLERANCE=0.02)                   | default  |
| tolerance.pct                             | 0.001                                    | Float/rounding drift threshold (0.1%)                                           | default  |
| match_key                                 | supplier_service_id+billing_period_start | Phase 1B exact join; service_map not yet implemented                            | default  |
| deduplication                             | exact_row_match                          | Duplicate invoice rows removed before reconciliation to prevent double-matching | default  |
| our_service_id_equals_supplier_service_id | True                                     | Phase 1B simplification: no service_map yet; IDs assumed equal across systems   | default  |
